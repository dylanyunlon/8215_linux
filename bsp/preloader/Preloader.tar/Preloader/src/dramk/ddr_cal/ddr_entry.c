/*----------------------------------------------------------------------------*
 * Copyright Statement:                                                       *
 *                                                                            *
 *   This software/firmware and related documentation ("MediaTek Software")   *
 * are protected under international and related jurisdictions'copyright laws *
 * as unpublished works. The information contained herein is confidential and *
 * proprietary to MediaTek Inc. Without the prior written permission of       *
 * MediaTek Inc., any reproduction, modification, use or disclosure of        *
 * MediaTek Software, and information contained herein, in whole or in part,  *
 * shall be strictly prohibited.                                              *
 * MediaTek Inc. Copyright (C) 2010. All rights reserved.                     *
 *                                                                            *
 *   BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND     *
 * AGREES TO THE FOLLOWING:                                                   *
 *                                                                            *
 *   1)Any and all intellectual property rights (including without            *
 * limitation, patent, copyright, and trade secrets) in and to this           *
 * Software/firmware and related documentation ("MediaTek Software") shall    *
 * remain the exclusive property of MediaTek Inc. Any and all intellectual    *
 * property rights (including without limitation, patent, copyright, and      *
 * trade secrets) in and to any modifications and derivatives to MediaTek     *
 * Software, whoever made, shall also remain the exclusive property of        *
 * MediaTek Inc.  Nothing herein shall be construed as any transfer of any    *
 * title to any intellectual property right in MediaTek Software to Receiver. *
 *                                                                            *
 *   2)This MediaTek Software Receiver received from MediaTek Inc. and/or its *
 * representatives is provided to Receiver on an "AS IS" basis only.          *
 * MediaTek Inc. expressly disclaims all warranties, expressed or implied,    *
 * including but not limited to any implied warranties of merchantability,    *
 * non-infringement and fitness for a particular purpose and any warranties   *
 * arising out of course of performance, course of dealing or usage of trade. *
 * MediaTek Inc. does not provide any warranty whatsoever with respect to the *
 * software of any third party which may be used by, incorporated in, or      *
 * supplied with the MediaTek Software, and Receiver agrees to look only to   *
 * such third parties for any warranty claim relating thereto.  Receiver      *
 * expressly acknowledges that it is Receiver's sole responsibility to obtain *
 * from any third party all proper licenses contained in or delivered with    *
 * MediaTek Software.  MediaTek is not responsible for any MediaTek Software  *
 * releases made to Receiver's specifications or to conform to a particular   *
 * standard or open forum.                                                    *
 *                                                                            *
 *   3)Receiver further acknowledge that Receiver may, either presently       *
 * and/or in the future, instruct MediaTek Inc. to assist it in the           *
 * development and the implementation, in accordance with Receiver's designs, *
 * of certain softwares relating to Receiver's product(s) (the "Services").   *
 * Except as may be otherwise agreed to in writing, no warranties of any      *
 * kind, whether express or implied, are given by MediaTek Inc. with respect  *
 * to the Services provided, and the Services are provided on an "AS IS"      *
 * basis. Receiver further acknowledges that the Services may contain errors  *
 * that testing is important and it is solely responsible for fully testing   *
 * the Services and/or derivatives thereof before they are used, sublicensed  *
 * or distributed. Should there be any third party action brought against     *
 * MediaTek Inc. arising out of or relating to the Services, Receiver agree   *
 * to fully indemnify and hold MediaTek Inc. harmless.  If the parties        *
 * mutually agree to enter into or continue a business relationship or other  *
 * arrangement, the terms and conditions set forth herein shall remain        *
 * effective and, unless explicitly stated otherwise, shall prevail in the    *
 * event of a conflict in the terms in any agreements entered into between    *
 * the parties.                                                               *
 *                                                                            *
 *   4)Receiver's sole and exclusive remedy and MediaTek Inc.'s entire and    *
 * cumulative liability with respect to MediaTek Software released hereunder  *
 * will be, at MediaTek Inc.'s sole discretion, to replace or revise the      *
 * MediaTek Software at issue.                                                *
 *                                                                            *
 *   5)The transaction contemplated hereunder shall be construed in           *
 * accordance with the laws of Singapore, excluding its conflict of laws      *
 * principles.  Any disputes, controversies or claims arising thereof and     *
 * related thereto shall be settled via arbitration in Singapore, under the   *
 * then current rules of the International Chamber of Commerce (ICC).  The    *
 * arbitration shall be conducted in English. The awards of the arbitration   *
 * shall be final and binding upon both parties and shall be entered and      *
 * enforceable in any court of competent jurisdiction.                        *
 *---------------------------------------------------------------------------*/
 /*-----------------------------------------------------------------------------
  *
  * Author: quanwe.tan
  * Date: 2013/08/25
  * RCSfile: chip_entry1.c, chip_entry2.c
  * Revision: #0
  *
  *---------------------------------------------------------------------------*/
#include "ddr_includes.h"


#define REG_RW_RKCFG                        0x0020      //RANK CONFIGURATION
#define RW_RKCFG_CHSEL_OFFSET               20          //001: address > 64MB, then channel B 010: address > 128MB, then channel B 011: address > 256MB, then channel B 100: address > 512MB, then channel B others: channel A
#define RW_RKCFG_CHSEL_MASK                 0x00700000  //dual channel selection
#define RW_RKCFG_CHSEL_64M                  0x1         //If DRAM > 64M, Channel 2, Else Channel 1
#define RW_RKCFG_CHSEL_128M                 0x2         //If DRAM > 128M, Channel 2, Else Channel 1
#define RW_RKCFG_CHSEL_256M                 0x3         //If DRAM > 256M, Channel 2, Else Channel 1
#define RW_RKCFG_CHSEL_512M                 0x4         //If DRAM > 512M, Channel 2, Else Channel 1


#define CONFIG_DRAM_SIZE_AUTO_MODEL         0           // Auto detect channel and size
#define CONFIG_SINGLE_DRAM_SIZE_256_MODEL   10
#define CONFIG_SINGLE_DRAM_SIZE_384_MODEL   11
#define CONFIG_SINGLE_DRAM_SIZE_512_MODEL   12
#define CONFIG_SINGLE_DRAM_SIZE_768_MODEL   13
#define CONFIG_SINGLE_DRAM_SIZE_128_MODEL   20

#define DRAM_SIZE_64M               		0x04000000
#define DRAM_SIZE_128M               		0x08000000
#define DRAM_SIZE_256M               		0x10000000
#define DRAM_SIZE_384M               		0x18000000
#define DRAM_SIZE_512M               		0x20000000
#define DRAM_SIZE_768M               		0x30000000
#define DRAM_SIZE_1024M              		0x40000000


#if 0
void ddr_init_dramc_dram(void)
{   
    // Init channel A DRAM.
    TCMSET_CHANNELA_ACTIVE();
    DDR_SetDramController();

#if 0
    // Init channel B DRAM.
    if (IS_DRAM_CHANNELB_SUPPORT())
    {
        mcSHOW_DBG_MSG("Channel B DRAM enable.\n");
		
        TCMSET_CHANNELB_ACTIVE();        
        DDR_SetDramController();
    }
#endif    
}
#endif


static void _DDR_CheckBLCfg(UINT32 u4Ch1DramSize, UINT32 u4Ch2DramSize)

{
    UINT32 u4RealDramSize;
    UINT32 u4CfgDramSize;
    
    u4RealDramSize = TCMGET_CHANNELA_SIZE();
    u4CfgDramSize = u4Ch1DramSize + u4Ch2DramSize;
    u4CfgDramSize = u4CfgDramSize>>20;

    if(u4CfgDramSize > u4RealDramSize)
	{

		LOG(1, "DDR config error!\n");
	#if 1
		LOG(1, "DDR PHY: %d MB\n", u4RealDramSize);
        LOG(1, "DDR CFG: %d MB\n", u4CfgDramSize);
	#endif
		while(1);
	} 
}


UINT32 _DDR_CheckSize(BOOL fgChBActive)
{  
    register UINT32 u4DramSize = 0x4000000;   // 64 Mbytes.
    register UINT32 u4CheckAddr1;
    register UINT32 u4CheckAddr2;  
    register UINT32 u4BaseAddr;      
    register UINT32 u4Val1;
    register UINT32 u4MaxAddr = 0x40000000;  // 1 Gbytes.

	BOOL fgSizingDone = FALSE;

    if (fgChBActive)
    {
        u4BaseAddr = INIT_DRAM_B_CHB_BASE;
    }
    else
    {
        u4BaseAddr = INIT_DRAM_B_BASE;
    }

    while ((!fgSizingDone) && (u4DramSize < u4MaxAddr))
    {
        u4CheckAddr1 = u4BaseAddr + (u4DramSize*1) - 4;
        *((volatile UINT32 *)u4CheckAddr1) = 0x12345678;
        u4CheckAddr2 = u4BaseAddr + (u4DramSize*2) - 4;
        *((volatile UINT32 *)u4CheckAddr2) = 0x55AACC33;
        
        u4Val1 = *((volatile UINT32 *)u4CheckAddr1);
        
        if (u4Val1 == 0x12345678)
        {
            u4DramSize *= 2;
        }
        else            
        {
            fgSizingDone = TRUE;
        }
    }
	
#if defined(CC_FORCE_DRAM768M) || defined(CC_FORCE_DRAM1G)
	if (!IS_DRAM_CHANNELB_ACTIVE())
		u4DramSize = 0x20000000;	// CHannel A 512M
	else
        #ifdef 	CC_FORCE_DRAM768M	
		u4DramSize = 0x10000000;	//Channel B 256M
        #else
		u4DramSize = 0x20000000;	//Channel B 512M
        #endif
#endif

    return u4DramSize;
}


void vDDR_DramReSizing(void)
{
	UINT32 u4Ch1DramSize = 0;
	UINT32 u4Ch2DramSize = 0;
	UINT32 u4BLDramCfg = 0;
    UINT32 u4Val;
    UINT32 u4RealDramSize;
    UINT32 i;
    
    u4RealDramSize = TCMGET_CHANNELA_SIZE();
    u4RealDramSize = u4RealDramSize<<20;

    u4BLDramCfg = BIM_READ32(REG_RW_GPRDW5); // load dram config
	u4BLDramCfg = DDR_GET_SIZE_CONFIG(u4BLDramCfg);
    u4Val = ucDram_Register_Read(mcSET_ARBITER_ADDR(0x00));
    mcCLR_MASK(u4Val,RW_RKCFG_CHSEL_MASK);
    /*Fix dram size single channel 256MB */
    //u4BLDramCfg = CONFIG_SINGLE_DRAM_SIZE_256_MODEL;
	//dram1/dram2 range setting
	switch(u4BLDramCfg)
	{
	case CONFIG_SINGLE_DRAM_SIZE_128_MODEL:
		u4Ch1DramSize = DRAM_SIZE_64M;
		u4Ch2DramSize = DRAM_SIZE_64M;	
		_DDR_CheckBLCfg(u4Ch1DramSize+u4Ch2DramSize, 0);
		ucDram_Register_Write(mcSET_ARBITER_ADDR(0x00), u4Val | (RW_RKCFG_CHSEL_128M << RW_RKCFG_CHSEL_OFFSET));	
		break;
	case CONFIG_SINGLE_DRAM_SIZE_256_MODEL:
		u4Ch1DramSize = DRAM_SIZE_128M;
		u4Ch2DramSize = DRAM_SIZE_128M;	
		_DDR_CheckBLCfg(u4Ch1DramSize+u4Ch2DramSize, 0);
		ucDram_Register_Write(mcSET_ARBITER_ADDR(0x00), u4Val | (RW_RKCFG_CHSEL_256M << RW_RKCFG_CHSEL_OFFSET));
		break;	

	case CONFIG_SINGLE_DRAM_SIZE_512_MODEL:
		u4Ch1DramSize = DRAM_SIZE_256M;
		u4Ch2DramSize = DRAM_SIZE_256M;	
		_DDR_CheckBLCfg(u4Ch1DramSize+u4Ch2DramSize, 0);
		ucDram_Register_Write(mcSET_ARBITER_ADDR(0x00), u4Val | (RW_RKCFG_CHSEL_512M << RW_RKCFG_CHSEL_OFFSET));
		break;

	default:
		u4Ch1DramSize = u4RealDramSize/2;
		u4Ch2DramSize = u4RealDramSize/2;

        i = 0;
        u4RealDramSize =  u4RealDramSize>>26;
        while(u4RealDramSize)
        {
            i++;
            u4RealDramSize = u4RealDramSize>>1;
        }
        ucDram_Register_Write(mcSET_ARBITER_ADDR(0x00), u4Val | (i << RW_RKCFG_CHSEL_OFFSET));
		break;
	}

    BIM_WRITE32(REG_RW_GPRDW6, u4Ch1DramSize);
    BIM_WRITE32(REG_RW_GPRDW7, u4Ch2DramSize);
}



static UINT32 _ddr_do_calibration(void)
{
	UINT32 u4Ret = 0;

#ifdef DRAM_RX_EYE_SCAN
	U8 dq_no=0;
#endif

#ifdef DRAM_Pll_PHASE_CAL
	DramcPllPhaseCal();
#endif

#ifdef DRAM_IMPEDANCE_CAL
	DramcImpedanceCalApply();
#endif

#ifdef DRAM_WRITE_LEVELING_CAL
	DramcWriteLeveling();
#endif

#ifdef DRAM_MiockJmeter	
	DramcMiockJmeter();
#endif

#ifdef DRAM_GATING_SCAN
	u4Ret = DramcRxdqsGatingCal();
#endif

#ifdef DRAM_RX_ODT_SCAN
	DramcRxOdtScan();
#endif

#ifdef DRAM_RX_WINDOW_PERBIT_CAL
	u4Ret |= DramcRxWindowPerbitCal();
#endif

#ifdef DRAM_RX_DATLAT_CAL
	DramcRxdatlatCal(0);
#endif

#ifdef DRAM_TX_OCD_DRV_SCAN
	DramcTxOcdDrvScan();
#endif

#ifdef DRAM_TX_VREF_CAL
	DramcTxVrefCal();
#endif

#ifdef DRAM_TX_WINDOW_PERBIT_CAL
	u4Ret |= DramcTxWindowPerbitCal();
#endif

#ifdef DRAM_RX_EYE_SCAN
	for(dq_no =0;dq_no<32;dq_no++)
		DramcRxEyeScan(dq_no);
#endif

#ifdef DRAM_TX_EYE_SCAN
	DramcTxEyeScan();
#endif

    return u4Ret;
}


void ddr_calibrate(void)
{   
	UINT32 u4Ret = 0;
	UINT32 u4Val;
	

	mcSHOW_DBG_MSG("DRAM Channel A Calibration.\n");
	

	TCMSET_CHANNELA_ACTIVE();
   
	u4Ret = _ddr_do_calibration();

		
	if (u4Ret == DRAM_OK)
    {
        TCMSET_CHANNELA_SIZE(_DDR_CheckSize(FALSE)/0x100000); //get channel A dram size
        mcSHOW_ERROR_CHIP_DisplayString("DRAM A Size = ");
        mcSHOW_ERROR_CHIP_DisplayInteger(TCMGET_CHANNELA_SIZE());
        mcSHOW_ERROR_CHIP_DisplayString(" Mbytes.\n");
		
		
    }
#if 0		
	if (IS_DRAM_CHANNELB_SUPPORT())
	{
		mcSHOW_DBG_MSG("DRAM Channel B Calibration.\n");

		TCMSET_CHANNELB_ACTIVE();
		
		u4Ret |= _ddr_do_calibration();
		
        if (u4Ret == DRAM_OK)
        {
            TCMSET_CHANNELB_SIZE(_DDR_CheckSize(TRUE)/0x100000);
            mcSHOW_ERROR_CHIP_DisplayString("DRAM B Size = ");       
            mcSHOW_ERROR_CHIP_DisplayInteger(TCMGET_CHANNELB_SIZE());
            mcSHOW_ERROR_CHIP_DisplayString(" Mbytes.\n");
			
        }
	
		// Back to channel A.
		TCMSET_CHANNELA_ACTIVE();
	}
#endif
			
}


#ifdef DRAM_WRITE_READ_LOOP_AFTER_CALIBRATION
void dram_test_after_cali(void)
{
    UINT32 i;
    UINT32 u4err_value;
    UINT32 test2_0 = DEFAULT_TEST2_0_CAL;
    UINT32 test2_1 = DEFAULT_TEST2_1_CAL;
    UINT32 test2_2 = DEFAULT_TEST2_2_CAL;
    
    for(i=0;(i*DEFAULT_TEST2_2_CAL*32)<(TCMGET_CHANNELA_SIZE()*1024*1024);i++)
    {
        test2_1 =  DEFAULT_TEST2_1_CAL | (i*DEFAULT_TEST2_2_CAL);
        u4err_value = DramcEngine2(TE_OP_WRITE_READ_CHECK, test2_0, test2_1, test2_2);

        if(!u4err_value)
        {   
            mcSHOW_DBG_MSG("Channel A ");
            mcSHOW_ERROR_CHIP_DisplayHex(i*DEFAULT_TEST2_2_CAL*32);
            mcSHOW_DBG_MSG(" ~ ");
            mcSHOW_ERROR_CHIP_DisplayHex((i+1)*DEFAULT_TEST2_2_CAL*32-1);
            mcSHOW_DBG_MSG(" Pass!!\n");
			

        }
        else
        {
            mcSHOW_DBG_MSG("Channel A ");
            mcSHOW_ERROR_CHIP_DisplayHex(i*DEFAULT_TEST2_2_CAL*32);
            mcSHOW_DBG_MSG(" ~ ");
            mcSHOW_ERROR_CHIP_DisplayHex((i+1)*DEFAULT_TEST2_2_CAL*32-1);
            mcSHOW_DBG_MSG(" Error!!\n");
            mcSHOW_DBG_MSG("Error value is ");
            mcSHOW_ERROR_CHIP_DisplayHex(u4err_value);
            mcSHOW_DBG_MSG(".\n");

            while(1);
        }
        mcDELAY_us(1000);
    }
        
    if (IS_DRAM_CHANNELB_SUPPORT())
    {
        TCMSET_CHANNELB_ACTIVE();
        
        for(i=0;(i*DEFAULT_TEST2_2_CAL*32)<(TCMGET_CHANNELB_SIZE()*1024*1024);i++)
        {
            u4err_value = DramcEngine2(TE_OP_WRITE_READ_CHECK, test2_0, test2_1, test2_2);
            if(!u4err_value)
            {
                mcSHOW_DBG_MSG("Channel B ");
                mcSHOW_ERROR_CHIP_DisplayHex(i*DEFAULT_TEST2_2_CAL*32);
                mcSHOW_DBG_MSG(" ~ ");
                mcSHOW_ERROR_CHIP_DisplayHex((i+1)*DEFAULT_TEST2_2_CAL*32-1);
                mcSHOW_DBG_MSG(" Pass!!\n");
            }
            else
            {
                mcSHOW_DBG_MSG("Channel B ");
                mcSHOW_ERROR_CHIP_DisplayHex(i*DEFAULT_TEST2_2_CAL*32);
                mcSHOW_DBG_MSG(" ~ ");
                mcSHOW_ERROR_CHIP_DisplayHex((i+1)*DEFAULT_TEST2_2_CAL*32-1);
                mcSHOW_DBG_MSG(" Error!!\n");
                mcSHOW_DBG_MSG("Error value is ");
                mcSHOW_ERROR_CHIP_DisplayHex(u4err_value);
                mcSHOW_DBG_MSG(".\n");
                while(1);
            }
            mcDELAY_us(1000);
        }
        TCMSET_CHANNELA_ACTIVE();
    }
}
#endif



