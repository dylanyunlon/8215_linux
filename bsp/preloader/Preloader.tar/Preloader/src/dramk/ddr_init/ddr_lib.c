/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/

/** @file ddr_init.c
 *  ddr init flow control.
 */
#include "ddr_includes.h"

#ifndef CC_DEFAULT_LOGLVL
#define CC_DEFAULT_LOGLVL 3
#endif

static UINT32 _u4DDRLogLvl = CC_DEFAULT_LOGLVL;

void DDR_SetLogLevel(UINT32 u4Level)
{
    _u4DDRLogLvl = u4Level;
}
UINT32  DDR_GetLogLevel(void)
{
    return _u4DDRLogLvl;
}

// After setting dram parameter, wait for stable

//for 8563 , delay number =2 >1us
#define DRAM_WAIT_VALUE     2//0x40

#define WAIT_DRAM_STABLE()                     \
do                                             \
{                                              \
    volatile UINT32 z;                         \
    for (z = 0; z < DRAM_WAIT_VALUE; z++) {};  \
} while (0)

//for 8563 u4Micros = us
void DDR_Delay(UINT32 u4Micros)
{
    /*
       Run on flash: 1 u4Micros = 1797us
       Run on TCM:   1 u4Micros = 0.81us
    */
  #if 1
    for (; u4Micros > 0; --u4Micros)
    {
        WAIT_DRAM_STABLE();
    }
  #else
    u4WaitNms(2,1,0);
  #endif
}

