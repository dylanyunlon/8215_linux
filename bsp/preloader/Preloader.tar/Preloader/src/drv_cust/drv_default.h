/*----------------------------------------------------------------------------*
 * Copyright Statement:                                                       *
 *                                                                            *
 *   This software/firmware and related documentation ("MediaTek Software")   *
 * are protected under international and related jurisdictions'copyright laws *
 * as unpublished works. The information contained herein is confidential and *
 * proprietary to MediaTek Inc. Without the prior written permission of       *
 * MediaTek Inc., any reproduction, modification, use or disclosure of        *
 * MediaTek Software, and information contained herein, in whole or in part,  *
 * shall be strictly prohibited.                                              *
 * MediaTek Inc. Copyright (C) 2010. All rights reserved.                     *
 *                                                                            *
 *   BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND     *
 * AGREES TO THE FOLLOWING:                                                   *
 *                                                                            *
 *   1)Any and all intellectual property rights (including without            *
 * limitation, patent, copyright, and trade secrets) in and to this           *
 * Software/firmware and related documentation ("MediaTek Software") shall    *
 * remain the exclusive property of MediaTek Inc. Any and all intellectual    *
 * property rights (including without limitation, patent, copyright, and      *
 * trade secrets) in and to any modifications and derivatives to MediaTek     *
 * Software, whoever made, shall also remain the exclusive property of        *
 * MediaTek Inc.  Nothing herein shall be construed as any transfer of any    *
 * title to any intellectual property right in MediaTek Software to Receiver. *
 *                                                                            *
 *   2)This MediaTek Software Receiver received from MediaTek Inc. and/or its *
 * representatives is provided to Receiver on an "AS IS" basis only.          *
 * MediaTek Inc. expressly disclaims all warranties, expressed or implied,    *
 * including but not limited to any implied warranties of merchantability,    *
 * non-infringement and fitness for a particular purpose and any warranties   *
 * arising out of course of performance, course of dealing or usage of trade. *
 * MediaTek Inc. does not provide any warranty whatsoever with respect to the *
 * software of any third party which may be used by, incorporated in, or      *
 * supplied with the MediaTek Software, and Receiver agrees to look only to   *
 * such third parties for any warranty claim relating thereto.  Receiver      *
 * expressly acknowledges that it is Receiver's sole responsibility to obtain *
 * from any third party all proper licenses contained in or delivered with    *
 * MediaTek Software.  MediaTek is not responsible for any MediaTek Software  *
 * releases made to Receiver's specifications or to conform to a particular   *
 * standard or open forum.                                                    *
 *                                                                            *
 *   3)Receiver further acknowledge that Receiver may, either presently       *
 * and/or in the future, instruct MediaTek Inc. to assist it in the           *
 * development and the implementation, in accordance with Receiver's designs, *
 * of certain softwares relating to Receiver's product(s) (the "Services").   *
 * Except as may be otherwise agreed to in writing, no warranties of any      *
 * kind, whether express or implied, are given by MediaTek Inc. with respect  *
 * to the Services provided, and the Services are provided on an "AS IS"      *
 * basis. Receiver further acknowledges that the Services may contain errors  *
 * that testing is important and it is solely responsible for fully testing   *
 * the Services and/or derivatives thereof before they are used, sublicensed  *
 * or distributed. Should there be any third party action brought against     *
 * MediaTek Inc. arising out of or relating to the Services, Receiver agree   *
 * to fully indemnify and hold MediaTek Inc. harmless.  If the parties        *
 * mutually agree to enter into or continue a business relationship or other  *
 * arrangement, the terms and conditions set forth herein shall remain        *
 * effective and, unless explicitly stated otherwise, shall prevail in the    *
 * event of a conflict in the terms in any agreements entered into between    *
 * the parties.                                                               *
 *                                                                            *
 *   4)Receiver's sole and exclusive remedy and MediaTek Inc.'s entire and    *
 * cumulative liability with respect to MediaTek Software released hereunder  *
 * will be, at MediaTek Inc.'s sole discretion, to replace or revise the      *
 * MediaTek Software at issue.                                                *
 *                                                                            *
 *   5)The transaction contemplated hereunder shall be construed in           *
 * accordance with the laws of Singapore, excluding its conflict of laws      *
 * principles.  Any disputes, controversies or claims arising thereof and     *
 * related thereto shall be settled via arbitration in Singapore, under the   *
 * then current rules of the International Chamber of Commerce (ICC).  The    *
 * arbitration shall be conducted in English. The awards of the arbitration   *
 * shall be final and binding upon both parties and shall be entered and      *
 * enforceable in any court of competent jurisdiction.                        *
 *---------------------------------------------------------------------------*/
#ifndef DRV_DEFAULT_H
#define DRV_DEFAULT_H

#ifndef DRAM_SETTING_VERSION
#define DRAM_SETTING_VERSION  "V1.0"
#endif

#ifndef DRAM_SUPPORT_PCB_TYPE
#define DRAM_SUPPORT_PCB_TYPE  "FPGA,EVB"
#endif


#ifndef DEFAULT_DDR_CLOCK
#define DEFAULT_DDR_CLOCK     1242000000
#endif

#ifndef DEFAULT_DRAM_TYPE
#define DEFAULT_DRAM_TYPE     (DDR_III_16_x1)
#endif

#ifndef DEFAULT_DRAM_COLADDR
#define DEFAULT_DRAM_COLADDR  (COL_ADDR_BIT_10)
#endif

#ifndef DEFAULT_DDR_CL
#define DEFAULT_DDR_CL        (11)
#endif

#ifndef DEFAULT_DDR_BUS_X8
#define DEFAULT_DDR_BUS_X8    (0)  // Default is BUS X 16.
#endif

#ifndef DMPLL_SPECTRUM_PERMILLAGE
//#define DMPLL_SPECTRUM_PERMILLAGE   (100) // +- 1%.
#define DMPLL_SPECTRUM_PERMILLAGE   (50) // +- 0.5%.
//#define DMPLL_SPECTRUM_PERMILLAGE   (0) // disable DRAM spread specturm.
#endif

#ifndef DMPLL_SPECTRUM_FREQUENCY
//#define DMPLL_SPECTRUM_FREQUENCY   (60) // Khz.
#define DMPLL_SPECTRUM_FREQUENCY    (30) // Khz.
//#define DMPLL_SPECTRUM_FREQUENCY   (0) // disable DRAM spread specturm.
#endif

#ifndef DRAM_PRIORITY_LIST
// Audio/0 > B2R/5 > VBI/3D/TVE/2 > SCPOS/7 > NR/PSCAN/4 > OSD/OD/MMU/3 > MJC_IN/13 > MJC_OUT/14 > DEMUX/GCPU/1 > CPU/6 > VLD1/9 > VDEC_MC/8 > Test0/15 > GFX/11 > VENC/12 > 3DGFX/10
#define DRAM_PRIORITY_LIST          ((UINT8*)"08254193bafde67c")
#endif

#ifndef DRAM_BURSTLEN
#define DRAM_BURSTLEN               0
#define AGTIM0 0xFFFFFFFF
#define AGTIM1 0xFFFF77FF
#endif

#ifndef DRAM_GROUP1ARBITERTIME
#define DRAM_GROUP1ARBITERTIME      5
#endif
#ifndef DRAM_GROUP2ARBITERTIME
#define DRAM_GROUP2ARBITERTIME      4
#endif
#ifndef DRAM_GROUP3ARBITERTIME
#define DRAM_GROUP3ARBITERTIME      15
#endif

#ifndef DEFAULT_DRAM_8_BANKS
#define DEFAULT_DRAM_8_BANKS        1
#endif

#ifndef FLAG_DDR_QFP
#define FLAG_DDR_QFP                0
#endif

#ifndef FLAG_DDR_DCBALANCE
#define FLAG_DDR_DCBALANCE		 0
#endif

#ifndef FLAG_DDR_16BITSWAP
#define FLAG_DDR_16BITSWAP    (FLAG_DDR_QFP)
#endif

#if (FLAG_DDR_QFP == 1)

    #ifndef DEFAULT_DRAM_RODT
    #define DEFAULT_DRAM_RODT      150
    #endif

    #ifndef DEFAULT_DRAM_WODT
    #define DEFAULT_DRAM_WODT      120
    #endif

#else /* #if (FLAG_DDR_QFP == 1) */

    #ifndef DEFAULT_DRAM_RODT
    #define DEFAULT_DRAM_RODT      150
    #endif

    #ifndef DEFAULT_DRAM_WODT
    #define DEFAULT_DRAM_WODT      60
    #endif

#endif /* #if (FLAG_DDR_QFP == 1) */


#endif /**/

