#ifndef _PRELOADER_BOOT_h
#define _PRELOADER_BOOT_h


#define NORMAL_BOOT   0x33633363
#define QUICK_BOOT    0x6D617273
#define EMMC_BOOT     0x636D6D65

extern unsigned  get_boot_type();

extern unsigned set_boot_type();



#define GPIO_POLARITY_LOW  0
#define GPIO_POLARITY_HIGH 1



#define GPIO_WAKEUP_STS    0
#define GPIO_WAKEUP_SRC    1
#define GPIO_PAD_IR        2


struct quickboot_param {
 
       unsigned int version;

       /*ddr calibration address */
       unsigned int ddr_cal_addr;
       /*os resume entry(physical address) */
       unsigned int resume_entry;
       /* wakeup source gpio & polarity config*/ 
       unsigned int wakeup_src_gpio;
       unsigned int wakeup_src_polarity;
       /*wakeup state gpio & polarity config*/
       unsigned int wakeup_sts_gpio;
       unsigned int wakeup_sts_polarity;
       
       /* delay time for system broad power off*/ 
       unsigned int power_off_delay;
       
       /* delay time for cpu reset*/
       unsigned int power_on_delay;

};


#endif
