/*----------------------------------------------------------------------------*
 * Copyright Statement:                                                       *
 *                                                                            *
 *   This software/firmware and related documentation ("MediaTek Software")   *
 * are protected under international and related jurisdictions'copyright laws *
 * as unpublished works. The information contained herein is confidential and *
 * proprietary to MediaTek Inc. Without the prior written permission of       *
 * MediaTek Inc., any reproduction, modification, use or disclosure of        *
 * MediaTek Software, and information contained herein, in whole or in part,  *
 * shall be strictly prohibited.                                              *
 * MediaTek Inc. Copyright (C) 2010. All rights reserved.                     *
 *                                                                            *
 *   BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND     *
 * AGREES TO THE FOLLOWING:                                                   *
 *                                                                            *
 *   1)Any and all intellectual property rights (including without            *
 * limitation, patent, copyright, and trade secrets) in and to this           *
 * Software/firmware and related documentation ("MediaTek Software") shall    *
 * remain the exclusive property of MediaTek Inc. Any and all intellectual    *
 * property rights (including without limitation, patent, copyright, and      *
 * trade secrets) in and to any modifications and derivatives to MediaTek     *
 * Software, whoever made, shall also remain the exclusive property of        *
 * MediaTek Inc.  Nothing herein shall be construed as any transfer of any    *
 * title to any intellectual property right in MediaTek Software to Receiver. *
 *                                                                            *
 *   2)This MediaTek Software Receiver received from MediaTek Inc. and/or its *
 * representatives is provided to Receiver on an "AS IS" basis only.          *
 * MediaTek Inc. expressly disclaims all warranties, expressed or implied,    *
 * including but not limited to any implied warranties of merchantability,    *
 * non-infringement and fitness for a particular purpose and any warranties   *
 * arising out of course of performance, course of dealing or usage of trade. *
 * MediaTek Inc. does not provide any warranty whatsoever with respect to the *
 * software of any third party which may be used by, incorporated in, or      *
 * supplied with the MediaTek Software, and Receiver agrees to look only to   *
 * such third parties for any warranty claim relating thereto.  Receiver      *
 * expressly acknowledges that it is Receiver's sole responsibility to obtain *
 * from any third party all proper licenses contained in or delivered with    *
 * MediaTek Software.  MediaTek is not responsible for any MediaTek Software  *
 * releases made to Receiver's specifications or to conform to a particular   *
 * standard or open forum.                                                    *
 *                                                                            *
 *   3)Receiver further acknowledge that Receiver may, either presently       *
 * and/or in the future, instruct MediaTek Inc. to assist it in the           *
 * development and the implementation, in accordance with Receiver's designs, *
 * of certain softwares relating to Receiver's product(s) (the "Services").   *
 * Except as may be otherwise agreed to in writing, no warranties of any      *
 * kind, whether express or implied, are given by MediaTek Inc. with respect  *
 * to the Services provided, and the Services are provided on an "AS IS"      *
 * basis. Receiver further acknowledges that the Services may contain errors  *
 * that testing is important and it is solely responsible for fully testing   *
 * the Services and/or derivatives thereof before they are used, sublicensed  *
 * or distributed. Should there be any third party action brought against     *
 * MediaTek Inc. arising out of or relating to the Services, Receiver agree   *
 * to fully indemnify and hold MediaTek Inc. harmless.  If the parties        *
 * mutually agree to enter into or continue a business relationship or other  *
 * arrangement, the terms and conditions set forth herein shall remain        *
 * effective and, unless explicitly stated otherwise, shall prevail in the    *
 * event of a conflict in the terms in any agreements entered into between    *
 * the parties.                                                               *
 *                                                                            *
 *   4)Receiver's sole and exclusive remedy and MediaTek Inc.'s entire and    *
 * cumulative liability with respect to MediaTek Software released hereunder  *
 * will be, at MediaTek Inc.'s sole discretion, to replace or revise the      *
 * MediaTek Software at issue.                                                *
 *                                                                            *
 *   5)The transaction contemplated hereunder shall be construed in           *
 * accordance with the laws of Singapore, excluding its conflict of laws      *
 * principles.  Any disputes, controversies or claims arising thereof and     *
 * related thereto shall be settled via arbitration in Singapore, under the   *
 * then current rules of the International Chamber of Commerce (ICC).  The    *
 * arbitration shall be conducted in English. The awards of the arbitration   *
 * shall be final and binding upon both parties and shall be entered and      *
 * enforceable in any court of competent jurisdiction.                        *
 *---------------------------------------------------------------------------*/
#ifndef X_DRAM_H
#define X_DRAM_H

#include "x_typedef.h"

// DRAM data read/write macros
#define INIT_DRAM_B_BASE            0x80000000
#define INIT_DRAM_B_CHB_BASE    	0xc0000000

// timeout for TE2: (CMP_CPT_POLLING_PERIOD X MAX_CMP_CPT_WAIT_LOOP) 
// complete flag, need to double check with DE
#define CMP_CPT_POLLING_PERIOD  2  // 1 
#define MAX_CMP_CPT_WAIT_LOOP  100  // max loop 100

#define DEFAULT_TEST2_0_CAL 0xaa550000   // patter 1 and 0
#define DEFAULT_TEST2_1_CAL 0x30000000   // base address for test engine when we do calibration, [30:28] is row mask, A15 masked
#define DEFAULT_TEST2_2_CAL 0x00000400   // offset address for test engine when we  do calibraion

// suspend/resume
#define DRAMC_BACKUP_REG_NUM   13+1   // number of backup registers in DRAMC when suspend//for datlat//for DRAM Prior// 13+2 Remove DRAMC_REG_CONF1
#define DRAMRB_BACKUP_REG_NUM  8   // number of backup registers in DRAMC when suspend//for datlat//for DRAM Prior
#define PHY_BACKUP_REG_NUM     70   // number of backup registers in DDRPHY when suspend
#define CHA_CHB_COMMON_REG_NUM 5	//cha&chb common register when suspend

#define   REG_RW_CONF     0x0
#define   REG_RW_PRI0     0x10
#define   REG_RW_PRI1     0x14
#define   REG_RW_AGTIM0   0x20
#define   REG_RW_AGTIM1   0x24
#define   REG_RW_STARVE1  0x34
#define   REG_RW_STARVE2  0x38
#define   REG_RW_STARVE6  0x48


//xtal frequency
#define XTAL_MHZ	    27   //Crystal is 27MHz

/***********************************************************************/
/*          Public Types                                               */
/***********************************************************************/
#if 0
typedef unsigned char   U8;
typedef unsigned short  U16;
typedef unsigned long   U32;
typedef unsigned int    UINT;

typedef signed char     S8;
typedef signed short    S16;
typedef signed long     S32;
typedef signed int      SINT;
#endif


typedef U32             DWORD;  //32 bits

typedef U8              Data8;
typedef U16             Data16;
typedef U32             Data32;

typedef U8              *PU8;
typedef U16             *PU16;
typedef U32             *PU32;
typedef S8              *PS8;
typedef S16             *PS16;

/***********************************************************************/
/*              Defines                                                */
/***********************************************************************/
#define ENABLE  1
#define DISABLE 0

typedef enum
{
    DRAM_OK = 0, // OK
    DRAM_FAIL    // FAIL
} DRAM_STATUS_T; // DRAM status type

typedef enum
{
	DRAM_CALIBRATION_PASS = 0,
	DRAM_CALIBRATION_FAIL,
	DRAM_CALIBRATION_WINDOW_SIZE_TOO_SMALL,
	DRAM_CALIBRATION_WINDOW_SIZE_TOO_BIG
} DRAM_CALIBRATION_STATUS;

typedef enum
{
    TE_OP_WRITE_READ_CHECK = 0,
    TE_OP_READ_CHECK
} DRAM_TE_OP_T;

typedef enum
{
    DLINE_0 = 0,
    DLINE_1,
    DLINE_TOGGLE    
} PLL_PHASE_CAL_STATUS_T;


////////////////////////////

typedef struct _RXDQS_PERBIT_DLY_T
{
    S8 first_dqdly_pass;
    S8 last_dqdly_pass;
    S8 first_dqsdly_pass;
    S8 last_dqsdly_pass;
    U8 best_dqdly;
    U8 best_dqsdly;
} RXDQS_PERBIT_DLY_T;

typedef struct _TXDQS_PERBIT_DLY_T
{
    S8 first_dqdly_l_pass;
    S8 last_dqdly_l_pass;
    S8 first_dqdly_r_pass;
    S8 last_dqdly_r_pass;
    S8 pi_dqdly_ok_center;
} TXDQS_PERBIT_DLY_T;

/************************ Bit Process *************************/
#define mcBITL(b)               (1L << (b))
#define mcBIT(b)                (1L << (b))
#define mcMASK(w)               (mcBIT(w) - 1)
#define mcMASKS(w, b)           (mcMASK(w) << (b))
#define mcFIELD(val, msk, pos)  (((val) << (pos)) & (msk))

#define mcSET_MASK(a, b)        ((a) |= (b))
#define mcCLR_MASK(a, b)        ((a) &= (~(b)))
#define mcCHK_MASK(a, b)        ((a) & (b))
//#define mcSET_BIT(a, b)         mcSET_MASK(a, mcBIT(b))
#define mcSET_BIT(a, b)         ((a) |= ((U32)1L<<(b)))
//#define mcCLR_BIT(a, b)         mcCLR_MASK(a, mcBIT(b))
#define mcCLR_BIT(a, b)         ((a) &= (~((U32)1L<<(b))))
#define mcCHK_BIT1(a, b)        ((a) & mcBIT(b))
#define mcCHK_BITM(a, b, m)     (((a) >> (b)) & (m))
#define mcCHK_BITS(a, b, w)     mcCHK_BITM(a, b, mcMASK(w))
//#define mcTEST_BIT(a, b)        mcCHK_BITM(a, b, 1)
#define mcTEST_BIT(a, b)        mcCHK_BIT1(a, b)
#define mcCHG_BIT(a, b)         ((a) ^= mcBIT(b))

#define mcSET_FIELD0(var, val, msk, pos)    mcSET_MASK(var, mcFIELD(val, msk, pos))

#define mcSET_FIELD(var, value, mask, pos)  \
{                                           \
    mcCLR_MASK(var, mask);                  \
    mcSET_FIELD0(var, value, mask, pos);    \
}

#define mcGET_FIELD(var, mask, pos)     (((var) & (mask)) >> (pos))

//mtk40739 modify this for 3363 code refine
//#define mcSET_DRAMC_REG_ADDR(offset)    ((IS_DRAM_CHANNELB_ACTIVE() ? DRAM_DRAMC_CHB_BASE : DRAM_DRAMC_BASE) | (offset))
#define mcSET_DRAMC_REG_ADDR(offset)     (DRAM_DRAMC_BASE | (offset))

#define mcSET_PHY_REG_ADDR(offset)    	((DRAM_DDRPHY_BASE) | (offset))

//mtk40739 modify this for 3363 code refine
//#define mcSET_ARBITER_ADDR(offset)		((IS_DRAM_CHANNELB_ACTIVE() ? DRAM_DMARB_CHB_BASE : DRAM_DMARB_BASE) | (offset))
#define mcSET_ARBITER_ADDR(offset)       (DRAM_DMARB_BASE  | (offset))


// DRAM controller register read/write macros
#define ucDram_Register_Read(reg)			HAL_READ32(reg)
#if 1
#define ucDram_Register_Write(reg, value)	HAL_WRITE32(reg, value)
#else
//For DE run simulation
#define ucDram_Register_Write(reg, value)	do{\
												HAL_WRITE32(reg, value); \
												Printf("RISCWrite(32'h%08X, 32'h%08X);\n", reg&(~0x70000000), value);\
											}while(0)


#endif
/***********************************************************************/

#if !defined(CC_MTK_PRELOADER) && !defined(CC_MTK_LOADER)
typedef struct _DRAM_CFG_T
{
    UINT8       ui1_ssc_range;
    UINT8       ui1_ssc_modulation;
    UINT8       ui1_clk_driving;
    UINT8       ui1_clk_delay;
    UINT8       ui1_cmd_driving;
    UINT8       ui1_cmd_delay;
    UINT8       ui1_wdqs_driving;
    UINT8       ui1_wdqs0_delay;
    UINT8       ui1_wdqs1_delay;
    UINT8       ui1_wdqs2_delay;    
    UINT8       ui1_wdqs3_delay;        
    UINT8       ui1_wdq_driving;
    UINT8       ui1_wdq0_delay;    
    UINT8       ui1_wdq1_delay;    
    UINT8       ui1_wdq2_delay; 
    UINT8       ui1_wdq3_delay;        
} DRAM_CFG_T;
#endif /* !defined(CC_MTK_PRELOADER) && !defined(CC_MTK_LOADER) */

// DDR related functions.
extern CHAR * DDR_DramTypeString(UINT32 u4Type);
extern UINT32 DDR_IsDqsFail(UINT32 u4DQSth, UINT32 u4DQSVal, UINT32 u4DQSType, UINT32 u4ChipNum);
extern UINT32 DDR_CalibrateDqs(void);
extern UINT32 DDR_CalibrateOutDqs(void);
extern void DDR_SetDramController(void);
extern void DDR_SetAgentPriority(const UINT8 *pu1Prio);
extern void DDR_SetBurstLen(UINT32 u4TimeSlot1, UINT32 u4TimeSlot2);
extern void DDR_SetArbiterTime(UINT8 u1Group, UINT8 u1Time);
extern UINT32 DRAMC_str_save_registers(UINT32 *u4DRAMCTemp, UINT32 u4Size);
extern void DRAMC_str_restore_registers(UINT32 *u4DRAMCTemp);
//extern void DRAMC_Exit_Suspend(UINT32 *u4DRAMCTemp);
extern void DMARC_TCM_suspend(void);
extern void DMARC_TCM_resume(void);
extern void DMARC_TCM_partial_resume(void);
extern U32 DramcEngine2(DRAM_TE_OP_T wr, U32 test2_0, U32 test2_1, U32 test2_2);

/*
    DRAM configuration API for factory mode.
        res_mngr\drv\u_drv_cust.h
        mw_if\drv_cust_api.c
*/ 
#if !defined(CC_MTK_PRELOADER) && !defined(CC_MTK_LOADER)
extern BOOL DDR_SetCustCfg(DRAM_CFG_T *prDdrCfg);
extern BOOL DDR_GetCustCfg(DRAM_CFG_T *prDdrCfg);
#endif /* !defined(CC_MTK_PRELOADER) && !defined(CC_MTK_LOADER) */

#define DRAM_DRAMC_READ32(offset)                    IO_READ32(DRAM_DRAMC_BASE, offset)
#define DRAM_DRAMC_WRITE32(offset, value)            IO_WRITE32(DRAM_DRAMC_BASE, offset, (value))

#define DRAM_DMARB_READ32(offset)                    IO_READ32(DRAM_DMARB_BASE, offset)
#define DRAM_DMARB_WRITE32(offset, value)            IO_WRITE32(DRAM_DMARB_BASE, offset, (value))

#define DRAM_DDRPHY_READ32(offset)                   IO_READ32(DRAM_DDRPHY_BASE, offset)
#define DRAM_DDRPHY_WRITE32(offset, value)           IO_WRITE32(DRAM_DDRPHY_BASE, offset, (value))

#define   REG_RW_DMSUS               0xF0024038
#define   BIT_DMSUS                  0

#define DRAMB_REG_DYNPRI             (0x0000006C)
#define BIT_PRIUPDAGE_EN             (1<<0)
#define BIT_PSTWRFLS_EN              (1<<5)
#define BIT_MERFLS_EN                 (1<<4)


#define DRAMB_REG_PRI0               (0x00000010)
#define DRAMB_REG_PRI1               (0x00000014) 
#define DRAMB_REG_DYNPRI             (0x0000006C)
#define DYNPRI0                       0x7f91E2D3
#define DYNPRI1                       0xFA45CB68
#define BIT_PRIUPDAGE_EN              (1<<0)


#define  DRAMB_REG_PROT0_0          (0x00000200) 
#define  REGION_BOUND_MASK          (0x7FFFFFFC)
#define  BIT_PROTECT_EN             (1U << 31)
#define  BIT_IN_PROTECT_MODE        (0U << 30)
#define  BIT_OUT_PROTECT_MODE       (1U << 30)
#define  BIT_WEN_PROTECT            (1U << 29) 
#define  BIT_REN_PROTECT            (1U << 28)

#define  DRAMB_REG_INTR0            (0x00000280)
#define  REG_RO_INTR0               (0x00006280)
#define  BIT_INTR_INTRUDEN          (1U << 31)
#define  INTRADR_MASK               (0x7FFFFFFC)

#define  DRAMB_REG_INTRUID0         (0x000002A0)
#define  INTR_AGTID_MASK            (0x0000000F)
#define  INTR_SUBID_MASK            (0x000000F0)
#define  INTR_SUBID_SHIFT           4

#define  DRAMB_REG_INTCLR           (0x00000270)
#define  INTCLR_MASK                (0xFFFFFFFE) 


#define  DRAMB_REG_BMCYC            (0x0000008C)
#define  BMCYC_MASK                 (0xFFFFFFFF) 
          

#define DRAMB_REG_BM                (0x00000080)
#define BM_GROUP1                   1
#define BM_GROUP2                   2
#define BM_GROUP3                   3
#define BM_BMGP1_AG_MASK            (0x00001F00)
#define BM_BMGP1_AG_OFFSET           8
#define BIT_BMGP1_EN                (1U << 15)
#define BM_BMGP2_AG_MASK            (0x00070000)
#define BM_BMGP2_AG_OFFSET          16
#define BIT_BMGP2_EN                (1U << 19)
#define BM_BMGP3_AG_MASK            (0x00700000)
#define BM_BMGP3_AG_OFFSET          20
#define BIT_BMGP3_EN                (1U << 23)
#define BIT_REQCNTEN                (1U << 30)
#define BIT_PACNTEN                 (1U << 31)


#define DRAMB_REG_BM0               (0x00000090)   
#define BM_BMGP_AG_MASK             (0x00700000)
#define BM_BMGP3_AG_OFFSET           20            
#define DRAMB_REG_BM3               (0x0000009C) 

#define DRAMB_REG_CONF               (0x00000000)
#define BIT_AG15_EN                  (1 << 29)
#define BIT_ARBCPUQK_EN              (1 << 23)
#define DEAFULT_TESTB_ADDR           (0x100000)
#define DRAMB_REG_TEST0_0            (0x00000100)
#define DEFALUT_TESTB_LEN            (0x800000)
#define DRAMB_REG_TEST0_1            (0x00000104)
#define DRAMB_REG_TEST               (0x00000118)
#define BIT_WAGENT_EN                (1 << 28)
#define BIT_PSTTHD                   12

#define DRAMB_REG_TEST0_RESULT       (0x00000140)
#define CMP_CPT0_MASK                (0x00000001)  //0
#define CMP_ERR0_OFFSET               4// 4
#define DLE_CNT_OK_OFFSET             8  //8

typedef struct
{
   DWORD dwHighAddr;
   DWORD dwLowAddr;
   DWORD dwProtectAgentID;
   BOOL  bEnableRegion;
   BOOL  bIncludeRegion;
   BOOL  bWriteProctect;
   BOOL  bReadProctect;
}T_REGIONINFO, *P_T_REGIONINFO;


typedef struct
{
    DWORD dwAgtID;
    DWORD dwSubID;
    DWORD dwAddr;
}T_INTRUDEINFO,*P_T_INTRUDEINFO;





#endif /* X_DRAM_H */
