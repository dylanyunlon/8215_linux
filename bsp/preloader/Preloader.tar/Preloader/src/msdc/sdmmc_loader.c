#include "x_typedef.h"
#include "msdc.h"


#define DATA_ZONE_OFFSET	0x00010000 // 64k offset in card phy address
#define DATAZONE_ADDRESS    0x06EFFC00 // read to the memory that before uboot

#define DRAMK_RUN_ADDRESS	0xF4008000 // SRAM 32K
#define DRAMK_PHY_OFFSET	0x00008000 // file_offset(31.5k) + bootloader_header(512bytes)
#define DRAMK_MAX_SIZE		0x8000	   // 32K

typedef struct _IMAGE_DESCRIPTOR
{
	UINT32 dwLoadAddress;	// reserve
	UINT32 dwLoadPhyAddr;	// dram address to load eboot
	UINT32 dwJumpAddress;	// reserve
	UINT32 dwJumpPhyAddr;	// entry point of eboot
	UINT32 dwStartAddr;		// eboot start address
	UINT32 dwTtlLen;		// eboot size
}IMAGE_DESCRIPTOR;
typedef void (*FUNC_CALL)(void);


extern UINT32 _dramk_loader_start;
extern UINT32 _dramk_loader_end;
extern UINT32 _dramk_loader_len;



// Constant definitions
BOOL SDInitializeHardware(UINT32 u4SdCh)
{
	UINT32 idret = MSDC_Identify_Card(u4SdCh);
	if (idret & MSDC_LASTERROR_IDENTIFY)
	{
		Printf("---->>> SD%x Identify Card Failed: %x <<<-----\r\n", MSDC_CH_INDEX(u4SdCh), idret);
		return FALSE;
	}
	
	MSDC_StateChange(u4SdCh, 0);		// Select card
	MSDC_SetBlockLength(u4SdCh, 512);	

	// Select clock
	#if defined(config_TARGET_REALCHIP)

	if (MSDC_Is_eMMC_Card(u4SdCh) && (u4SdCh == MSDC_CH1))
	{
		//Printf("---> eMMC 27MHz <---\r\n");
		//MSDC_SetClockRate(u4SdCh, 13500000); // Real clock is 13.5MHz
		MSDC_EnterHighSpeedMode(u4SdCh);
		MSDC_SetClockRate(u4SdCh, 27000000); // Real clock is 27MHz
	}
	else
	{
		MSDC_SetClockRate(u4SdCh, 13500000); // Real clock is 13.5MHz
		//MSDC_SetClockRate(u4SdCh, 6750000); // Real clock is 6.75MHz
	}
	
	#elif defined(config_TARGET_FPGA)

	MSDC_SetClockRate(u4SdCh, 5000000);

	#endif
	
	return TRUE;
}

//0x8C000000
BOOL IsValidDecriptor(const IMAGE_DESCRIPTOR *pDescriptor)
{
#if defined(Config_WinCE)
    if (pDescriptor
        && 0x8C000000 == pDescriptor->dwJumpAddress - pDescriptor->dwJumpPhyAddr
        && 0x8C000000 == pDescriptor->dwLoadAddress - pDescriptor->dwLoadPhyAddr)
#else  
    if (pDescriptor
        && 0x88D60000 == pDescriptor->dwJumpAddress - pDescriptor->dwJumpPhyAddr
        && 0x88D60000 == pDescriptor->dwLoadAddress - pDescriptor->dwLoadPhyAddr)
#endif
    {
        return TRUE;
    }

    return FALSE;
}

#if 0  // Max Xia Marked: Use another boot partition ops to get data from emmc, DON'T Delete it.
UINT32 sdmmc_loader(UINT32 u4SdCh)
{
	UINT32 i = 0;
	UINT32 ret = 0;
	UINT32 u4ReadOffset = 0,u4EndAddr = 0;
	UINT8 *pEbootAddr = 0;
    BOOL bRet = FALSE;
	BOOL bNeedReInit = FALSE;
    IMAGE_DESCRIPTOR *eboot_des = NULL;  

	UINT32 u4ZoneIndex,u4BegIndex,u4EndIndex;


	Printf("Init SD%x Card\r\n", MSDC_CH_INDEX(u4SdCh));

	#ifdef config_TARGET_REALCHIP
	// Setting for SD_V33_18_SW0/1/2 Issue, make IO Voltage is 3.3V for SD2.0 Spec
	MSDC_WRITE32(0x308, (MSDC_READ32(0x308) | 0xD0000000));
	MSDC_WRITE32(0x80, (MSDC_READ32(0x80) | 0x001C0000));
	MSDC_WRITE32(0xEC, (MSDC_READ32(0xEC) & 0xFFE3FFFF));
	#endif
	
    if(!SDInitializeHardware(u4SdCh))
    {
    	return FALSE;
    }
	Printf("Init SD%x Card Succuss\r\n", MSDC_CH_INDEX(u4SdCh));

	Dump_Card_Type(u4SdCh, 3);

	//***************************************
	// Handle Dramk. Execute dramk for enable DRAM
	//***************************************

	// if it is emmc, dramk in boot partition 
	if (MSDC_Is_eMMC_Card(u4SdCh))
	{
		bNeedReInit = TRUE;
		// Step 1 - Copy dramk from eMMC boot partition to SRAM
		
		ret = MSDC_EMMC_EnterBootMode0(u4SdCh);
		if(ret != MSDC_LASTERROR_EMMCBOOTMODE | MSDC_LASTERROR_OK)
		{
			Printf("Enter emmc boot mode failed: %X\r\n", ret);
			return FALSE;
		}
		ret = MSDC_EMMC_Read(u4SdCh, DRAMK_PHY_OFFSET,(UINT32 *)DRAMK_RUN_ADDRESS, DRAMK_MAX_SIZE);
		if(ret != (MSDC_LASTERROR_EMMCREAD | MSDC_LASTERROR_OK))
    	{
    		Printf("Read Dramk From Boot Partition 1 Failed");

			ret = MSDC_EMMC_ExitBootMode0(u4SdCh);
			if(ret != (MSDC_LASTERROR_EMMCBOOTMODE | MSDC_LASTERROR_OK))
			{
				Printf("Exit emmc boot mode failed");
				return FALSE;
			}

			// Read Dramk from boot partition 2
			ret = MSDC_EMMC_ReadFromBoot2(u4SdCh, DRAMK_PHY_OFFSET, DRAMK_RUN_ADDRESS, DRAMK_MAX_SIZE);
			if(ret != (MSDC_LASTERROR_EMMCBOOT2 | MSDC_LASTERROR_OK))
			{
				Printf("read dramk from emmc boot partition 2 failed");
				return FALSE;
			}
		}

		ret = MSDC_EMMC_ExitBootMode0(u4SdCh);
		if(ret != (MSDC_LASTERROR_EMMCBOOTMODE | MSDC_LASTERROR_OK))
		{
			Printf("Exit emmc boot mode failed");
			return FALSE;
		}

		// Step 2 - Execute dramk to init DRAM
  		DDR_Initialize();
  	
	}
	else // SD Card
	{
		// Step 1 - Copy dramk from SD to SRAM
		MSDC_SetBusWidth(u4SdCh, 4);
		MSDC_ReadBlock_PIO(u4SdCh, DRAMK_PHY_OFFSET, (UINT32 *)DRAMK_RUN_ADDRESS, DRAMK_MAX_SIZE);

		// Step 2 - Execute dramk to init DRAM
  		DDR_Initialize();
	}

	//**************************************************
	// Handle Datazone. Get eboot setting from datazone 
	//**************************************************

	if (bNeedReInit) // Need re-init card after operate  emmc boot partition
	{
	    if(!SDInitializeHardware(u4SdCh))
	    {
	    	return FALSE;
	    }
	}

	// Read Datazone for Addresses
	MSDC_ReadBlock_PIO(u4SdCh, DATA_ZONE_OFFSET, (UINT32 *)DATAZONE_ADDRESS, 512);

	eboot_des = ((IMAGE_DESCRIPTOR*)(DATAZONE_ADDRESS + 0x4C));
	Printf("eboot_img_des:\n");
	Printf("\tdwLoadAddress:0x%08x\n", eboot_des->dwLoadAddress);
	Printf("\tdwLoadPhyAddr:0x%08x\n", eboot_des->dwLoadPhyAddr);
	Printf("\tdwJumpAddress:0x%08x\n", eboot_des->dwJumpAddress);
	Printf("\tdwJumpPhyAddr:0x%08x\n", eboot_des->dwJumpPhyAddr);
	Printf("\tdwStartAddr:0x%08x\n", eboot_des->dwStartAddr);
	Printf("\tdwdwTtlLen0x%08x\n", eboot_des->dwTtlLen);
   	
    if (!IsValidDecriptor(eboot_des))
    {
        Printf("Not Valid image descriptor:0x%x\n", u4SdCh);
        return FALSE;
    }

    u4ReadOffset = eboot_des->dwStartAddr ;
	u4EndAddr =  u4ReadOffset + eboot_des->dwTtlLen;
    pEbootAddr = (UINT8 *)eboot_des->dwLoadPhyAddr;

	Printf("Now! Load uboot......\r\n");

	//*********************************************
	// Handle eboot/uboot. Read it and jump to execute it
	//*********************************************

	MSDC_ReadBlock_PIO(u4SdCh,u4ReadOffset,(UINT32 *)pEbootAddr,eboot_des->dwTtlLen);

	
	
	//Printf("Load Eboot completed, dump 160 bytes:\r\n");
	//for(i = 0; i < 160; i++)
	//{
	//	Printf("%X ", *(pEbootAddr+i));
	//	if ((i + 1) % 16 == 0)
	//	{
	//		Printf("\r\n");
	//	}
	//}


	
	#if 0
    while( u4ReadOffset < u4EndAddr)
	{
	   MSDC_ReadBlock_PIO(MSDC_CH1,u4ReadOffset,(UINT32 *)pEbootAddr,512);
       pEbootAddr+=512;
       u4ReadOffset+=512;
	}
	
	*(UINT32 *)(508) = 0XFFFFFFFF;
	MSDC_WriteBlock_PIO(BOOT_CH,DATA_ZONE_OFSET,(UINT32 *)0X0,512);
	#endif

	//Printf("Jump to uboot...\r\n");
	((FUNC_CALL)(eboot_des->dwJumpPhyAddr))();
}

#endif


UINT32 msdc_env_setting()
{
	// Setting for SD_V33_18_SW0/1/2 Issue, make IO Voltage is 3.3V for SD2.0 Spec
	MSDC_WRITE32(0x308, (MSDC_READ32(0x308) | 0xD0000000));
	MSDC_WRITE32(0x80, (MSDC_READ32(0x80) | 0x001C0000));
	MSDC_WRITE32(0xEC, (MSDC_READ32(0xEC) & 0xFFE3FFFF));

#if 0  // Use the blow code, will cause uart output garbage data, marked it for check rootcause in the future, search "MARKED_UART_ISSUE"
	// ================= eMMC Bootup, SD0 Top Misc Setting ================
	// CLK Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_PUPD_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_DRV_MASK, 0x5); 

	// CMD Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_DRV_MASK, 0x5);

	// DAT0 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_DRV_MASK, 0x5);

	// DAT1 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_DRV_MASK, 0x5);

	// DAT2 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_DRV_MASK, 0x5);

	// DAT3 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_DRV_MASK, 0x5);

	// DAT4 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_DRV_MASK, 0x5);

	// DAT5 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_DRV_MASK, 0x5);

	// DAT6 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_DRV_MASK, 0x5);

	// DAT7 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_DRV_MASK, 0x5);

	// RST Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_RST, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_RST, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_RST, PAD_CFG_PUPD_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_RST, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD0_RST, PAD_CFG_DRV_MASK, 0x5);
	


	// ================= SD1 Top Misc Setting ================
	// CLK Pad
	MSDC_SET_FIELD(PAD_CFG_SD1_CLK, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_CLK, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_CLK, PAD_CFG_PUPD_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_CLK, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_CLK, PAD_CFG_DRV_MASK, 0x5); 

	// CMD Pad
	MSDC_SET_FIELD(PAD_CFG_SD1_CMD, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_CMD, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_CMD, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD1_CMD, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_CMD, PAD_CFG_DRV_MASK, 0x5);

	// DAT0 Pad
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT0, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT0, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT0, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT0, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT0, PAD_CFG_DRV_MASK, 0x5);

	// DAT1 Pad
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT1, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT1, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT1, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT1, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT1, PAD_CFG_DRV_MASK, 0x5);

	// DAT2 Pad
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT2, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT2, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT2, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT2, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT2, PAD_CFG_DRV_MASK, 0x5);

	// DAT3 Pad
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT3, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT3, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT3, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT3, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_DAT3, PAD_CFG_DRV_MASK, 0x5);

	// RST Pad
	MSDC_SET_FIELD(PAD_CFG_SD1_RST, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_RST, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_RST, PAD_CFG_PUPD_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_RST, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD1_RST, PAD_CFG_DRV_MASK, 0x5);

	// ================= SD2 Top Misc Setting ================
	// CLK Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_PUPD_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_DRV_MASK, 0x5); 

	// CMD Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_DRV_MASK, 0x5);

	// DAT0 Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_DRV_MASK, 0x5);
#if 0

	// DAT1 Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_DRV_MASK, 0x5);

	// DAT2 Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_DRV_MASK, 0x5);

	// DAT3 Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_PUPD_MASK, 0);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_DRV_MASK, 0x5);

	// RST Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_RST, PAD_CFG_SMT_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_RST, PAD_CFG_RESISTOR_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_RST, PAD_CFG_PUPD_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_RST, PAD_CFG_IES_MASK, 1);
	MSDC_SET_FIELD(PAD_CFG_SD2_RST, PAD_CFG_DRV_MASK, 0x5);
#endif
#else
	// ================= eMMC Bootup, SD0 Top Misc Setting ================
	// CLK Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_RESISTOR_MASK, 	1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_PUPD_MASK, 		1 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_CLK, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT); 

	// CMD Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_RESISTOR_MASK, 	1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_PUPD_MASK, 		0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_CMD, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT0 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT0, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT1 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT1, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT2 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT2, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT3 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT3, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT4 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT4, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT5 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT5, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT6 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT6, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT7 Pad
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD0_DAT7, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// ================= SD2 Top Misc Setting ================
	// CLK Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_RESISTOR_MASK, 	1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_PUPD_MASK, 		1 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_CLK, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT); 

	// CMD Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_RESISTOR_MASK, 	1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_PUPD_MASK, 		0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_CMD, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT0 Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT0, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT1 Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT1, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT2 Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT2, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

	// DAT3 Pad
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_SMT_MASK, 		1 << PAD_CFG_SMT_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_RESISTOR_MASK, 1 << PAD_CFG_RESISTOR_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_PUPD_MASK, 	0 << PAD_CFG_PUPD_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_IES_MASK, 		1 << PAD_CFG_IES_SHFIT);
	MSDC_SET_FIELD(PAD_CFG_SD2_DAT3, PAD_CFG_DRV_MASK, 		0x5 << PAD_CFG_DRV_SHFIT);

#endif
	return 0;
}


#define BOOTHDR_TOTAL_SIZE		(512)
#define BOOTHR_ID1_SIZE			(12)
#define BOOTHR_ID2_SIZE			(8)

#define BOOTHR_ID1	"BOOTLOADER!"			// Must be BOOTHR_ID1_SIZE chars
#define BOOTHR_ID2	"MT3360A"				// Must be BOOTHR_ID2_SIZE chars

typedef struct _NANDINFO_
{
   UINT16   pageSize;        /* 512, 2048 */
   UINT16   spareSize;
   UINT16   addressCycle;   
   UINT16   pageShift;	
}NANDINFO_t;

typedef struct _CARDINFO_
{
    UINT32 cardType;
    UINT32 cardSize;
}CARDINFO_t;

typedef union _MEDIAINFO_
{
	NANDINFO_t 	Nand;
	CARDINFO_t	Card;
}MEDIAINFO_t;

typedef struct _BOOTHDR_
{
   	char ID1[BOOTHR_ID1_SIZE];
   	char version[4];
   	UINT32 length;
   	UINT32 startAddr;
   	UINT32 checksum;
   	char ID2[BOOTHR_ID2_SIZE];
	MEDIAINFO_t media;
    UINT32  options;
   	UINT16 pagesPerBlock;   
   	UINT16  totalBlocks;
   	UINT16  blockShift;
   	UINT16  linkAddr[4];
   	UINT16  lastBlock;
} BOOTHDR_t;

const char BootHdr_ID1[] = BOOTHR_ID1;
const char BootHdr_ID2[] = BOOTHR_ID2;


UINT32 VerifyBootHdr(BOOTHDR_t *pBootHdr)
{
    UINT32 n;
    UINT32 BootHdr_DuplicationNum = BOOTHDR_TOTAL_SIZE / sizeof(BOOTHDR_t);
    while(BootHdr_DuplicationNum--)
    {
        n=0;
        for(n=0;n<BOOTHR_ID1_SIZE;n++)
        {
            if(pBootHdr->ID1[n]!= BootHdr_ID1[n])
            {
                return 0x01;
            }
        }

        for(n=0;n<BOOTHR_ID2_SIZE;n++)
        {
            if(pBootHdr->ID2[n]!= BootHdr_ID2[n])
            {
                return 0x02;
            }
        }
        pBootHdr++;
    }

    return 0;
}

UINT32 sdmmc_loader(UINT32 u4SdCh)
{
	UINT32 i = 0;
	UINT32 ret = 0;
	UINT32 u4EbootFileOffset = 0;
	UINT32 u4EbootLoadPhyAddr = 0;
	UINT32 u4EbootLen = 0;
	UINT32 u4EbootJumpPhyAddr = 0;
    BOOL bRet = FALSE;
    IMAGE_DESCRIPTOR *eboot_des = NULL;

	UINT32 u4ZoneIndex,u4BegIndex,u4EndIndex;

	UINT8 *pDramkStart = (UINT8 *)(&_dramk_loader_start);
    UINT8 *pDramkEnd = (UINT8 *)(&_dramk_loader_end);
	UINT32 u4DramkLength = ALIGN((pDramkEnd - pDramkStart), 512); 
	//UINT32 u4DramkLength = ALIGN((_dramk_loader_len), 512); 
	//UINT32 u4DramkLength = (UINT32)(_dramk_loader_len); 
	if (u4DramkLength > DRAMK_MAX_SIZE)
	{
		Printf("dramk size error\r\n");
		u4DramkLength = DRAMK_MAX_SIZE;
	}

	Printf("Init SD%x Card\r\n", MSDC_CH_INDEX(u4SdCh));

	#ifdef config_TARGET_REALCHIP
	msdc_env_setting();	
	#endif

	#if 1
    if(!SDInitializeHardware(u4SdCh))
    {
    	return FALSE;
    }

	#else
	
	for(i = 0; i < 5; i++)
	{
		if (SDInitializeHardware(u4SdCh))
			break;

		if (i == 4)
			return FALSE;
	}
	#endif
	
	Printf("Init SD%x Card Succuss\r\n", MSDC_CH_INDEX(u4SdCh));

	Dump_Card_Type(u4SdCh, 3);

	//***************************************
	// Handle Dramk. Execute dramk for enable DRAM
	//***************************************

	// if it is emmc, dramk in boot partition 
	// Now, some emmc work in boot mode with 4 bit bus width has some issue, so we not change emmc bus width here. 
	if (!MSDC_Is_eMMC_Card(u4SdCh))
	{
		MSDC_SetBusWidth(u4SdCh, 4);

		// Check BOOT HEADER for SD Card
		ret = MSDC_ReadBlock_PIO(u4SdCh, 0, (UINT32 *)DRAMK_RUN_ADDRESS, BOOTHDR_TOTAL_SIZE);
		if (VerifyBootHdr((BOOTHDR_t *)DRAMK_RUN_ADDRESS))
        	return FALSE;
	}  
	
	// Check bootloader position info
	MSDC_ReadBlock_PIO(u4SdCh, DATA_ZONE_OFFSET, (UINT32 *)DRAMK_RUN_ADDRESS, 512);

	eboot_des = ((IMAGE_DESCRIPTOR*)(DRAMK_RUN_ADDRESS + 0x4C));
	Printf("eboot_img_des:\n");
	Printf("\tdwLoadAddress:0x%08x\n", eboot_des->dwLoadAddress);
	Printf("\tdwLoadPhyAddr:0x%08x\n", eboot_des->dwLoadPhyAddr);
	Printf("\tdwJumpAddress:0x%08x\n", eboot_des->dwJumpAddress);
	Printf("\tdwJumpPhyAddr:0x%08x\n", eboot_des->dwJumpPhyAddr);
	Printf("\tdwStartAddr:0x%08x\n", eboot_des->dwStartAddr);
	Printf("\tdwdwTtlLen0x%08x\n", eboot_des->dwTtlLen);

    if (!IsValidDecriptor(eboot_des))
    {
        Printf("Not Valid image descriptor:0x%x\n", u4SdCh);
        return FALSE;
    }

    u4EbootFileOffset 	= eboot_des->dwStartAddr ;
	u4EbootLen			= eboot_des->dwTtlLen;
	u4EbootLoadPhyAddr 	= eboot_des->dwLoadPhyAddr;
	u4EbootJumpPhyAddr	= eboot_des->dwJumpPhyAddr;
	

	//***************************************
	// Handle Dramk. Execute dramk for enable DRAM
	//***************************************

	// if it is emmc, dramk in boot partition 
	if (MSDC_Is_eMMC_Card(u4SdCh) && (u4SdCh == MSDC_CH1))
	{
		// Step 1 - Copy dramk from eMMC boot partition to SRAM	
		ret = MSDC_EMMC_EnterBootMode1(u4SdCh);
		if(ret != MSDC_LASTERROR_EMMCBOOTMODE | MSDC_LASTERROR_OK)
		{
			Printf("Enter emmc boot mode failed\n");
			return FALSE;
		}

		// Check BOOT HEADER for eMMC Card (from boot partition)
		ret = MSDC_ReadBlock_PIO(u4SdCh, 0, (UINT32 *)DRAMK_RUN_ADDRESS, BOOTHDR_TOTAL_SIZE);
		if (VerifyBootHdr((BOOTHDR_t *)DRAMK_RUN_ADDRESS))
        	return FALSE;

		// Read DRAMK
		ret = MSDC_ReadBlock_PIO(u4SdCh, DRAMK_PHY_OFFSET, (UINT32 *)DRAMK_RUN_ADDRESS, u4DramkLength);
		if(ret != (MSDC_LASTERROR_READBLOCK | MSDC_LASTERROR_OK))
    	{
    		Printf("Read dramk from boot partition failed\n");
			return FALSE;
		}

		ret = MSDC_EMMC_ExitBootMode1(u4SdCh);
		if(ret != (MSDC_LASTERROR_EMMCBOOTMODE | MSDC_LASTERROR_OK))
		{
			Printf("Exit emmc boot mode failed\n");
			return FALSE;
		}
		
		// Step 2 - Execute dramk to init DRAM
  		DDR_Initialize();
        ddr_calibrate();
		
		//PAY ATTENTION TO: some emmc switch to 4 bit bus width will failed to read data. 
		//Printf("---> eMMC Switch to 8bit Buswidth <---\r\n");
		MSDC_SetBusWidth(u4SdCh, 8);
	}
	else // SD Card
	{
		// Step 1 - Copy dramk from SD to SRAM
		MSDC_ReadBlock_PIO(u4SdCh, DRAMK_PHY_OFFSET, (UINT32 *)DRAMK_RUN_ADDRESS, u4DramkLength);
		
		// Step 2 - Execute dramk to init DRAM
  		DDR_Initialize();
		ddr_calibrate();
	}	

	Printf("Now! Load uboot......\r\n");

	//*********************************************
	// Handle eboot/uboot. Read it and jump to execute it
	//*********************************************
	MSDC_ReadBlock_PIO(u4SdCh, u4EbootFileOffset, (UINT32 *)u4EbootLoadPhyAddr, u4EbootLen);
	
	// Jump to uboot
	((FUNC_CALL)(u4EbootJumpPhyAddr))();
}
//add for USB EP test 

#if 0

extern void Launch();

UINT32 sdmmc_loader(UINT32 u4SdCh)
{

	UINT32 i = 0;
	UINT32 ret = 0;
	UINT32 u4ReadOffset = 0,u4EndAddr = 0;
	UINT8 *pEbootAddr = 0;
    BOOL bRet = FALSE;
    IMAGE_DESCRIPTOR *eboot_des = NULL;
	UINT32 jumpAdrr = 0;


    
    UINT32 u4SDAddr = 0, u4ImageSize = 0;
     UINT32 *pbImageBuf = 0;
    

	UINT32 u4ZoneIndex,u4BegIndex,u4EndIndex;

	UINT8 *pDramkStart = (UINT8 *)(&_dramk_loader_start);
    UINT8 *pDramkEnd = (UINT8 *)(&_dramk_loader_end);
	UINT32 u4DramkLength = ALIGN((pDramkEnd - pDramkStart), 512); 
	//UINT32 u4DramkLength = ALIGN((_dramk_loader_len), 512); 
	//UINT32 u4DramkLength = (UINT32)(_dramk_loader_len); 
	if (u4DramkLength > DRAMK_MAX_SIZE)
	{
		Printf("dramk size error\r\n");
		u4DramkLength = DRAMK_MAX_SIZE;
	}


	Printf("Init SD%x Card\r\n", MSDC_CH_INDEX(u4SdCh));

	#ifdef config_TARGET_REALCHIP
	// Set clock source ,TODO
	//MSDC_WRITE32(0x3801C, 0x1);
	//MSDC_WRITE32(0xC4, 0xFFFFFFFF);
	//MSDC_WRITE32(0xA8, 0xFFFFFFFF);

	// Setting for SD_V33_18_SW0/1/2 Issue, make IO Voltage is 3.3V for SD2.0 Spec
	MSDC_WRITE32(0x308, (MSDC_READ32(0x308) | 0xD0000000));
	MSDC_WRITE32(0x80, (MSDC_READ32(0x80) | 0x001C0000));
	MSDC_WRITE32(0xEC, (MSDC_READ32(0xEC) & 0xFFE3FFFF));
	#endif
	
    if(!SDInitializeHardware(u4SdCh))
    {
    	return FALSE;
    }
	Printf("Init SD%x Card Succuss\r\n", MSDC_CH_INDEX(u4SdCh));

	Dump_Card_Type(u4SdCh, 3);

	//***************************************
	// Handle Dramk. Execute dramk for enable DRAM
	//***************************************


	// if it is emmc, dramk in boot partition 
	if (MSDC_Is_eMMC_Card(u4SdCh))
	{
		// Step 1 - Copy dramk from eMMC boot partition to SRAM	
		ret = MSDC_EMMC_EnterBootMode1(u4SdCh);
		if(ret != MSDC_LASTERROR_EMMCBOOTMODE | MSDC_LASTERROR_OK)
		{
			Printf("Enter emmc boot mode failed");
			return FALSE;
		}
		ret = MSDC_ReadBlock_PIO(u4SdCh, DRAMK_PHY_OFFSET, (UINT32 *)DRAMK_RUN_ADDRESS, u4DramkLength);
		if(ret != (MSDC_LASTERROR_READBLOCK | MSDC_LASTERROR_OK))
    	{
    		Printf("Read dramk from boot partition failed");
			return FALSE;
		}

		ret = MSDC_EMMC_ExitBootMode1(u4SdCh);
		if(ret != (MSDC_LASTERROR_EMMCBOOTMODE | MSDC_LASTERROR_OK))
		{
			Printf("Exit emmc boot mode failed");
			return FALSE;
		}
		
		// Step 2 - Execute dramk to init DRAM
  		DDR_Initialize();

		//SDInitializeHardware(u4SdCh);
		// TODO: Fix switch to 4 bit bus width error
		MSDC_SetBusWidth(u4SdCh, 4);
	}
	else // SD Card
	{
		// Step 1 - Copy dramk from SD to SRAM
		MSDC_SetBusWidth(u4SdCh, 4);
		MSDC_ReadBlock_PIO(u4SdCh, DRAMK_PHY_OFFSET, (UINT32 *)DRAMK_RUN_ADDRESS, u4DramkLength);

		// Step 2 - Execute dramk to init DRAM
  		DDR_Initialize();
	}

	//**************************************************
	// Handle Datazone. Get eboot setting from datazone 
	//**************************************************
	Printf("IMG++.\r\n");
	Printf("IMG++.\r\n");
	Printf("IMG++.\r\n");

#if 0

	MSDC_ReadBlock_PIO(u4SdCh, SDADRR_UIMAGE, (UINT32 *)PA_UIMAGE, SIZE_UIMAGE);
	Printf("IMG.\r\n");
	Printf("IMG.\r\n");
	Printf("IMG.\r\n");

	MSDC_ReadBlock_PIO(u4SdCh, SDADRR_INITRD,(UINT32 *)PA_INITRD, SIZE_INITRD);
	Printf("INITR.\r\n");
	Printf("INITR.\r\n");
	Printf("INITR.\r\n");
	Printf("INITR.\r\n");

    //pEbootAddr = (UINT8 *)(0X8F963000-0X8C000000);//(eboot_des->dwLoadPhyAddr  - 0X1000000);
	//Printf("Load Eboot...(sd)pEbootAddr=0x%x\r\n",pEbootAddr);
	//jumpAdrr = (UINT32)(pEbootAddr+0X1000);//eboot_des->dwJumpPhyAddr - 0X1000000 ;
	jumpAdrr = (UINT32)(PA_UIMAGE);
	
	//*((UINT32*)(0xF000C004)) = 0xE2;

	//Printf("Jump to 0x%x. [%x %x %x %x]\r\n",jumpAdrr,((UINT8*)jumpAdrr)[0], 
	//					((UINT8*)jumpAdrr)[1],((UINT8*)jumpAdrr)[2],((UINT8*)jumpAdrr)[3]);
	Printf("lunch %x \r\n",jumpAdrr);
	Printf("lunch %x \r\n",jumpAdrr);
	Printf("lunch %x \r\n",jumpAdrr);
	((FUNC_CALL)jumpAdrr)();
	//Launch();
	while(1);

#endif 
     u4SDAddr = 0x509400;
     pbImageBuf = (UINT32 *)0x2800;
     u4ImageSize = 0x4D7;


     if (u4ImageSize % 512)
     {
         u4ImageSize = (u4ImageSize / 512 + 1) * 512;
     }
     MSDC_ReadBlock_PIO(u4SdCh, u4SDAddr, pbImageBuf, u4ImageSize);
     Printf("AC8317.dtb. u4SDAddr:%x pbImageBuf:%x u4ImageSize:%x\r\n", u4SDAddr, pbImageBuf, u4ImageSize);
     
     u4SDAddr = 0x709400;
     pbImageBuf = (UINT32 *)0x8000;
     u4ImageSize = 0x4912C4;
     if (u4ImageSize % 512)
     {
         u4ImageSize = (u4ImageSize / 512 + 1) * 512;
     }
     MSDC_ReadBlock_PIO(u4SdCh, u4SDAddr, pbImageBuf, u4ImageSize);
     Printf("Image. u4SDAddr:%x pbImageBuf:%x u4ImageSize:%x\r\n", u4SDAddr, pbImageBuf, u4ImageSize);
    
     u4SDAddr = 0xC09400;
     pbImageBuf = (UINT32 *)0x700000;
     u4ImageSize = 0xF06543;
     if (u4ImageSize % 512)
     {
         u4ImageSize = (u4ImageSize / 512 + 1) * 512;
     }
     MSDC_ReadBlock_PIO(u4SdCh, u4SDAddr, pbImageBuf, u4ImageSize);
     Printf("initrd.img.gz. u4SDAddr:%x pbImageBuf:%x u4ImageSize:%x\r\n", u4SDAddr, pbImageBuf, u4ImageSize);
    
     Launch();
     while(1);


	// Read Datazone for Addresses
	/*MSDC_ReadBlock_PIO(u4SdCh, DATA_ZONE_OFFSET, (UINT32 *)DATAZONE_ADDRESS, 512);

	eboot_des = ((IMAGE_DESCRIPTOR*)(DATAZONE_ADDRESS + 0x4C));
	Printf("eboot_img_des:\n");
	Printf("\tdwLoadAddress:0x%08x\n", eboot_des->dwLoadAddress);
	Printf("\tdwLoadPhyAddr:0x%08x\n", eboot_des->dwLoadPhyAddr);
	Printf("\tdwJumpAddress:0x%08x\n", eboot_des->dwJumpAddress);
	Printf("\tdwJumpPhyAddr:0x%08x\n", eboot_des->dwJumpPhyAddr);
	Printf("\tdwStartAddr:0x%08x\n", eboot_des->dwStartAddr);
	Printf("\tdwdwTtlLen0x%08x\n", eboot_des->dwTtlLen);*/
#if 0
    if (!IsValidDecriptor(eboot_des))
    {
        Printf("Not Valid image descriptor:0x%x\n", u4SdCh);
        return FALSE;
    }
#endif
    u4ReadOffset = eboot_des->dwStartAddr ;
	u4EndAddr =  u4ReadOffset + eboot_des->dwTtlLen;
    pEbootAddr = (UINT8 *)eboot_des->dwLoadPhyAddr;

	Printf("Now! Load uboot......\r\n");

	//*********************************************
	// Handle eboot/uboot. Read it and jump to execute it
	//*********************************************

	MSDC_ReadBlock_PIO(u4SdCh,u4ReadOffset,(UINT32 *)pEbootAddr,eboot_des->dwTtlLen);

	// Jump to uboot
	((FUNC_CALL)(eboot_des->dwJumpPhyAddr))();
}



Launch	
	ldr r1, =0x1388
	ldr r2, =0x2800
	ldr r3, =0x0
	ldr r4, =0x0
	ldr r5, =0x0
	ldr r6, =0x0
	ldr r7, =0x0
	ldr r8, =0x0
	ldr r9, =0x0
	ldr r10, =0x0
	ldr r11, =0x0
	ldr r12, =0x0
	ldr pc, =0x8000

    END


#endif 

