#include "x_typedef.h"

#include "nfi2.h"
#include "nfi_drv.h"
#include "mtd_nand.h"
#include "bl_loader.h"
#include "x_printf.h"
#include "x_util.h"




#define NFI_TYPES_COMBINATION   6
#define __ALIGN_MASK(x,mask)	(((x)+(mask))&~(mask))
#define ALIGN(x,a)		__ALIGN_MASK(x,(typeof(x))(a)-1)

UINT8* _pTempMemPtr;
UINT32 _u4Config_no = 0;
NFI_DRV_t nand_driver;

NFI_MENU _rNFI2Retrials[NFI_TYPES_COMBINATION] = 
{  /* sector size, spare size, address cycle, page shift */   
   {/*IO_8BITS,*/  1024, 26, 5, 16}, // 12 bit ECC
   {/*IO_8BITS,*/  1024, 16, 5, 16},  // 6 bit ECC   
   {/*IO_8BITS,*/  1024, 16, 4, 16},  // 6 bit ECC   
   {/*IO_8BITS,*/  512, 16, 4, 8}, // 6 bit ECC    
   {/*IO_8BITS,*/  512, 16, 4, 16}, // 6 bit ECC    
   {/*IO_8BITS,*/  512, 16, 3,  8}, // 6 bit ECC
};



extern UINT32 _dramk_loader_start;
extern UINT32 _dramk_loader_end;
extern UINT32 _dramk_loader_len;


const char _szBLID1[12] = "BOOTLOADER!";
const char _szBLID2[8] = "NFIINFO";

BOOTL_HEADER _rBLHeader ;
PARTITION_NFB_TABLE  g_tPartitonNFBTable;
#define DATA_ZONE_NAND_OFSET	0x00010000 // 32k --->change to 64Kz
#define E_BOOT_ITEM_OFSET		(DATA_ZONE_NAND_OFSET + 0x4C)
#define MAX_EBOOT_NUM           100 //20
//use 60 bit or 24 bit or not. 
#define IO_BASE_ADDRESS1                    0xf0000000L

#define DRAMK_SDRAM_ADDR	0xF4008000 // SRAM 32K
#define SDRAM_ADDR_START    0xF4000000
#define PLR_HEAD_SIZE 	    0x200 // file_offset(31.5k) + bootloader_header(512bytes)
#define TMP_SDRAM_ADDR      0xF4007000 





void DumpBytes2( BYTE *pBuf, int size )
{
	int i;
	
	for(i=0;i<size;i++)
	{
		if( !(i % 16) )
			Printf("\r\n%Xh: ",i);
			
		
		Printf("%x ",*pBuf);
		
		pBuf++;
	}
    Printf("\r\n");
	
}


typedef void (*FUNC_CALL)(void);



/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:         BootLoader2HeaderVerification

Description:      Get NandFlash Inforamtion through Bootloader Head

Arguments:      pu4TmpBuf  - [in] For Get NandFlash Information Buffer
                        u4PgIdx       - [in] page index
                        iNo               - [in]configure Number
		
Return Value:    0:success

-------------------------------------------------------------------*/
INT8 BootLoader2HeaderVerification(UINT32 *pu4TmpBuf, UINT32 u4PgIdx, INT8 iNo)
{

    INT32           i = 0, index = 0;
    NFI_MENU      *pCurConfig = &(nand_driver.pConfigs[iNo]);
    STATUS_E ret;
    volatile UINT32         *pu4Source = pu4TmpBuf;   
    BOOTL_HEADER  *pTempHeader;
    volatile UINT32         *p4Source, *p4Destination;
	nand_driver.pCurConfig = pCurConfig;
  
    for ( i = 0 ;  i < ((pCurConfig->pageSize) >> 2); i++)
    {
        pu4Source[i] = 0x00;
    }
	nand_driver.Config((NFI_MENU *)&(nand_driver.pConfigs[iNo]));  
	
    while (index < 0x3) // 3 page is enough, first block must be a good block, ROM code limitation
    {
        ret = nand_driver.ReadPage((UINT32*)pu4Source, NULL,u4PgIdx, FALSE);
        if (ret == S_TIMEOUT){
            return -3; // read timeout, change config immediately
        }
        else if ( ret == S_ECC_UNCORRECT_ERR) // ECC detectable error, 2 bit error
        {
            index++; // read again, read disturb cause ECC error can be taken as good data, wrong config will be dismissed by signature check
            //return -3;
        }
        else if ( (ret == S_DONE) || (S_ECC_CORRECTABLE_ERR == ret) ) // correct or ECC correctable
            break;
        else  // unknown, exception
            return -3;

    }

    pTempHeader = (BOOTL_HEADER*)pu4Source;
    index = 0;
    // Reading all replications
    while ( index<REPLICATION_NUMBER )
    {

        // Tracing ID1, BOOTLOADER! 
        for (i=0; i<12; i++)
        {
            if ( pTempHeader[index].ID1[i] != _szBLID1[i] )
            break;
        }
        if ( i < 12)
        {
            index++;
            continue;
        }

        for (i=0; i<8; i++)
        {
            if ( pTempHeader[index].ID2[i] != _szBLID2[i] )
            break;
        }
        if ( i < 8)
        {
            index++;
            continue;
        }

        pCurConfig->pageSize = pTempHeader[index].NFIinfo.pageSize;
        pCurConfig->pageShift = pTempHeader[index].NFIinfo.pageShift;

        if (pCurConfig->spareSize == 16)
        { 
            if ((pCurConfig->spareSize *  uidiv(pCurConfig->pageSize,SECTOR_BYTES)) != pTempHeader[index].NFIinfo.spareSize)
            {
                index++;
                continue;            
            }
        }
        else if (pCurConfig->spareSize > 16)
        { //26, maximun spare size for 12 correctable ECC bits
        	UINT32 temp = (nand_driver.type == NFI_24BIT_ECC)? 26:pCurConfig->spareSize;
            if ((temp * uidiv(pCurConfig->pageSize,SECTOR_BYTES)) > pTempHeader[index].NFIinfo.spareSize)
            {
                index++;
                continue;            
            }        
        }
      
        // Tracking Nand-flash information      
        if  ( /*(pTempHeader[index].NFIinfo.IOInterface!= pCurConfig->IOInterface) ||*/
    //       (pTempHeader[index].NFIinfo.pageSize != pCurConfig->pageSize) || // pageSize is read from header, not by tryout
           (pTempHeader[index].NFIinfo.addressCycle != pCurConfig->addressCycle)  
    //       (pTempHeader[index].NFIinfo.pageShift!=pCurConfig->pageShift) //pageShift is also read from header
          )
        {
            // NFI configuration incorrect
            // Perhaps error bits existing
            index++;
            continue;
        }      

        nand_driver.Config((NFI_MENU *)&(nand_driver.pConfigs[iNo]));


        // all ID and PageFormat setting are matched
        p4Source = (volatile UINT32*)&pTempHeader[index];
        p4Destination = (volatile UINT32*)&_rBLHeader;
        for (i=0; i<(sizeof(BOOTL_HEADER)>>2); i++)
        {
          *p4Destination++ = *p4Source++;  
        }

	      Printf("index %d ok\r\n", index);
		//while(1);
        return 0;
      
    }
 	//Printf("err\r\n");
    return -1; // no single complete ID string is matched

}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:       NandFlashInit

Description:    NandFlash Initiliaze

Arguments:      pu4TmpBuf  - [in] For Get NandFlash Information Buffer
		
Return Value:   0: success

-------------------------------------------------------------------*/
INT8 NandFlashInit(UINT32 *pu4TmpBuf)
{
    INT8   iStatus = 0;
	UINT32 au4PgIdxTabl[]={0,64,128,256,512};
    UINT32 u4PgIdx = 0, dwTryLoop = 0;
    _u4Config_no = 0;

	/*1. Set NandFlash driver as 24bit*/
	nand_driver.type = NFI_24BIT_ECC;
	nand_driver.Init = NFI2_Init;
	nand_driver.Config = NFI2_Config;
	nand_driver.ReadPage = NFI2_ReadPage;
	nand_driver.pConfigs = _rNFI2Retrials;
	nand_driver.pCurConfig = _rNFI2Retrials;
	nand_driver.configSize = 6;
	
	
	/*2. NFI Initiliaze*/
	Printf("Start Init\n");
    nand_driver.Init();

    /*3. Get NandFlash Configure Information : Page Size, Spare size Block Per Page*/
    // loop 1: Trying the correct setting.
    for(dwTryLoop = 0; dwTryLoop <(sizeof(au4PgIdxTabl)/sizeof(au4PgIdxTabl[0])) ; dwTryLoop++)
	{
	    u4PgIdx  = au4PgIdxTabl[dwTryLoop];
		_u4Config_no = 0;
	    do
        {
            iStatus = BootLoader2HeaderVerification(pu4TmpBuf,u4PgIdx, _u4Config_no);
		    Printf("_u4Config_no =%d,status=%d, PageIdx=%d\n",_u4Config_no,iStatus, u4PgIdx);
           // The correct Bootloader ID is found in either of the replications
           if ( iStatus == 0 )
		   {
		       break;
		   }
		   _u4Config_no++;
		}while ( _u4Config_no< nand_driver.configSize);

	    // Fails in retrieving bootloader header via either NFI combination (NFIRetrials)
	    // ID is inexisted from neither replications.
	    if ( _u4Config_no < NFI_TYPES_COMBINATION )
	    {
	        Printf("Init Flash Ok _u4Config_no =%d, PageIdx=%d\n",_u4Config_no,iStatus, u4PgIdx);
	        break;
	    }
		
	}

	if(dwTryLoop >=(sizeof(au4PgIdxTabl)/sizeof(au4PgIdxTabl[0])))
	{
	    Printf("NandFlash Init Failed\n");
	}

	nand_driver.pCurConfig = &(nand_driver.pConfigs[_u4Config_no]);
	return iStatus;
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:       fgCheckValidBlock

Description:      Block is good or bad

Arguments:      u4PgIdx              - [in] page index
                      
                        pu4TmpPageBuf  - [in]Temp Page Buffer
		
Return Value:    TRUE:good block FALSE:Bad block

-------------------------------------------------------------------*/
BOOL fgCheckValidBlock(UINT32 u4PgIdx, UINT32* pu4TmpPageBuf)
{

   UINT32 u4Loop = 0;
   UINT8 Spare[8];
   
   for (u4Loop =0; u4Loop <2; u4Loop++)
   {
      // Read the bad block marking from the first page
      if (S_DONE != nand_driver.ReadPage(pu4TmpPageBuf, (UINT32 *)Spare,u4PgIdx + u4Loop,TRUE))
      {
          Printf("[_fgCheckValidBlock]bad block %d\n",u4PgIdx/_rBLHeader.pagesPerBlock);
		  return FALSE;

      }else
      {//Read success
		if(Spare[0]!=0xFF)
		{
			Printf("[_fgCheckValidBlock]bad block %d\n",u4PgIdx/_rBLHeader.pagesPerBlock);
			return FALSE;
		}
      }
   }

  if (S_DONE != nand_driver.ReadPage(pu4TmpPageBuf, (UINT32 *)Spare,u4PgIdx+_rBLHeader.pagesPerBlock-1,TRUE))
  {
      Printf("[_fgCheckValidBlock]bad block %d\n",u4PgIdx/_rBLHeader.pagesPerBlock);
	  return FALSE;
   }
   else
   {   //Read success
       if(Spare[0]!=0xFF)
	   {
	       Printf("[_fgCheckValidBlock]bad block %d\n",u4PgIdx/_rBLHeader.pagesPerBlock);
		   return FALSE;
	   }
    }
         
   return TRUE;

}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:        InitNandBlockTable

Description:      Initiliaze NandFlash Block index Table

Arguments:       pu4TmpPageBuf     - [in]Temp Page Buffer
                      
                       
Return Value:    

-------------------------------------------------------------------*/

void InitNandBlockTable(UINT32 *pu4TmpPageBuf)
{
    UINT32 u4LogBlockID = 0, u4PhyBlockID = 0;
	UINT16* p2NFBTable = (UINT16*)(g_tPartitonNFBTable.p2NFBTable); 
	for ( u4PhyBlockID = 0; u4PhyBlockID < MAX_EBOOT_NUM ; u4PhyBlockID++)
    {
        if (fgCheckValidBlock(u4PhyBlockID*_rBLHeader.pagesPerBlock,pu4TmpPageBuf))
        {
            //Printf("Log -Phy:%d <-> %d\r\n",u4LogBlockID,u4PhyBlockID);
            p2NFBTable[u4LogBlockID] = u4PhyBlockID;
            u4LogBlockID++;
        }
	}
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:       i4NFBPartitionRead

Description:      Block is good or bad

Arguments:      p4MemPtr             - [in/out] Mem buffer
                       u4Addr                   -[in]  Logical address start
                       u4Length                -[in] Logical address length
                        pu4TmpPageBuf     - [in]Temp Page Buffer
		
Return Value:    

-------------------------------------------------------------------*/
INT32 i4NFBPartitionRead(UINT32* p4MemPtr, UINT32 u4Addr, UINT32 u4Length, UINT8 *puTmpPageBuf)
{

  UINT32 u4PageSize = 0, u4FlashPtr = 0, u4Offset = 0,u4PageIndex = 0, u4TmpIdx = 0, u4TmpOfst = 0, u4EndAddr = 0;
  STATUS_E ret= S_UNKNOWN_ERR;
  UINT16* p2NFBTable = (UINT16*)(g_tPartitonNFBTable.p2NFBTable);
  u4FlashPtr = u4Addr;
  u4EndAddr = u4Addr + u4Length;
  u4PageSize = _rBLHeader.NFIinfo.pageSize;
  

  while ( u4FlashPtr < u4EndAddr)
  {
  	u4TmpIdx = uidiv(u4FlashPtr, (_rBLHeader.pagesPerBlock * _rBLHeader.NFIinfo.pageSize));
	u4TmpOfst = (uidiv(u4FlashPtr,_rBLHeader.NFIinfo.pageSize))&(_rBLHeader.pagesPerBlock - 1);
    u4PageIndex = p2NFBTable[u4TmpIdx] * _rBLHeader.pagesPerBlock + u4TmpOfst;    
 	if ( u4FlashPtr & ( u4PageSize -1) )
    {
		// if (S_DONE != (ret = NFI_ReadPage((UINT32*)_pTempMemPtr, u4PageIndex, TRUE, FALSE, 0, 0)))
		if (S_DONE != (ret = nand_driver.ReadPage((UINT32 *)puTmpPageBuf,NULL, u4PageIndex, FALSE)))
		{
			goto end;
		}
		else
		{
			u4Offset = u4FlashPtr & (u4PageSize - 1);
			if (u4EndAddr >= u4FlashPtr + u4PageSize - u4Offset )
			{
				mem_cpy(p4MemPtr, (UINT32*)(puTmpPageBuf + u4Offset), u4PageSize - u4Offset);
				p4MemPtr += ((u4PageSize - u4Offset) >> 2);
			}
			else if ( u4EndAddr < u4FlashPtr + u4PageSize - u4Offset)
			{
				mem_cpy(p4MemPtr,(UINT32*)(puTmpPageBuf + u4Offset),u4EndAddr - u4FlashPtr);
				p4MemPtr += ((u4EndAddr - u4FlashPtr) >> 2);
			}


       u4FlashPtr+= u4PageSize - u4Offset;
	 }
    }
    else
    {
   
	     u4Offset = u4FlashPtr & (u4PageSize - 1);
		 if ( u4EndAddr < u4FlashPtr + u4PageSize - u4Offset)
		{
		// if (S_DONE != (ret = NFI_ReadPage((UINT32*)_pTempMemPtr, u4PageIndex, TRUE, FALSE, 0, 0)))
			 if (S_DONE != (ret = nand_driver.ReadPage((UINT32*)puTmpPageBuf, NULL,u4PageIndex, FALSE)))
			{
		  		goto end;
			}
			mem_cpy((UINT8*)p4MemPtr,(UINT32*)(puTmpPageBuf + u4Offset),u4EndAddr - u4FlashPtr);
			p4MemPtr += ((u4EndAddr - u4FlashPtr) >> 2);
		}
		else
		{
		//  if (S_DONE != (ret = NFI_ReadPage((UINT32*)p4MemPtr, u4PageIndex, TRUE, FALSE, 0, 0)))
			if (S_DONE != (ret = nand_driver.ReadPage(p4MemPtr, NULL,u4PageIndex, FALSE)))
			{
			  goto end;
			}
			p4MemPtr += ((u4PageSize - u4Offset) >> 2 );
		}
	u4FlashPtr+= u4PageSize - u4Offset;
    }
  }
end:
  if (S_DONE!= ret)
  {
  	 return FALSE;
  }
  return TRUE;
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:         NandFlashInfoInit

Description:     NandFlash Information Initiliaze

Arguments:      pu4TmpBuf    - [in] Temp buffer

		
Return Value:  

-------------------------------------------------------------------*/
BOOL NandFlashInfoInit(UINT32 *pu4TmpBuf)
{
    /*1 NandFlash Information Initialize*/
	NandFlashInit(pu4TmpBuf);

	/*2. Init Block Index Table*/
	InitNandBlockTable(pu4TmpBuf);
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:          FindPhy2Log

Description:      Find Logical Block ID  by Physical Block ID

Arguments:      u4PhyBlockID             - [in] Physical Block ID
		
Return Value:    Logical Block ID 

-------------------------------------------------------------------*/
UINT32 FindPhy2Log(UINT32 u4PhyBlockID)
{
    UINT32 u4LogBlockID = 0; 
	UINT16* p2NFBTable = (UINT16*)(g_tPartitonNFBTable.p2NFBTable);
	while(u4LogBlockID <= u4PhyBlockID)
	{
	    if(p2NFBTable[u4LogBlockID] == u4PhyBlockID)
		{
		    break;
		}
		u4LogBlockID++;
	}
	Printf("\t PhyBlock ID is %d and Logical Block ID is %d\n",u4PhyBlockID,u4LogBlockID);
	return u4LogBlockID;
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:          GetDataZoneInfo

Description:      Get Datazone Information

Arguments:      pu4DZInfo             - [in/out] DataZone Information
		
Return Value:    TRUE on success

-------------------------------------------------------------------*/
BOOL GetDataZoneInfo(UINT32 *pu4DZInfo)
{
    BOOL bRet = TRUE;
    /*1. Get Jump Information from Datazone*/
	if((bRet = i4NFBPartitionRead(pu4DZInfo, E_BOOT_ITEM_OFSET, ALIGN_4_HIGH(DATAZONE_SIZE - DAZONE_ITEM_OFFSET),(UINT8*)MEM_BUF_MTD_TMP_MEM_PTR)) == FALSE)
	{
	    Printf("Using Backup DataZone Address 0x %x:\n",(E_BOOT_ITEM_OFSET+_rBLHeader.pagesPerBlock*_rBLHeader.NFIinfo.pageSize));
	    /*2. Get Backup Datazone Address*/ 
		bRet = i4NFBPartitionRead(pu4DZInfo, (E_BOOT_ITEM_OFSET+_rBLHeader.pagesPerBlock*_rBLHeader.NFIinfo.pageSize),
		      ALIGN_4_HIGH(DATAZONE_SIZE - DAZONE_ITEM_OFFSET),(UINT8*)MEM_BUF_MTD_TMP_MEM_PTR);
	}
	return bRet;
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:          GetEbootContent

Description:      Get Eboot Content

Arguments:      eboot_des             - [in/out] Eboot information
                        u4RelBL                 - [in]  Relocate or not
		
Return Value:    TRUE on success

-------------------------------------------------------------------*/
BOOL GetEbootContent(IMAGE_DESCRIPTOR *eboot_des,  UINT32 u4RelBL)
{
    BOOL bRet = TRUE;
	UINT32  u4PhyEbootBlockStart = 0,u4LogEbootBlockStart = 0,u4BlockSize = _rBLHeader.pagesPerBlock*_rBLHeader.NFIinfo.pageSize;
    if(u4RelBL == USE_BLRELOCATE)
	{
	    /*1. Get Relocate Eboot Location*/
		u4PhyEbootBlockStart = *(UINT32 *)(MEM_BUF_SECURE_BOOT_1 + RELPHYEBOOT_START);
		u4LogEbootBlockStart =  FindPhy2Log(u4PhyEbootBlockStart);
		Printf("\t [Relocate] Eboot Physical Block is %d Logical Block is %d\n", u4PhyEbootBlockStart,u4LogEbootBlockStart);
		if(i4NFBPartitionRead((UINT32 *) (eboot_des->dwLoadPhyAddr), u4LogEbootBlockStart*u4BlockSize,eboot_des->dwTtlLen,(UINT8*)MEM_BUF_MTD_TMP_MEM_PTR)!= TRUE)
		{
			/*2. Get Relocate Backup Eboot location*/
			u4PhyEbootBlockStart = *(UINT32 *)(MEM_BUF_SECURE_BOOT_1 + RELPHYBAKUPEBOOT_START);
		    u4LogEbootBlockStart =  FindPhy2Log(u4PhyEbootBlockStart);
		    Printf("\t [Relocate] Using Backup Eboot Physical Block is %d Logical Block is %d\n", u4PhyEbootBlockStart,u4LogEbootBlockStart);
			if(i4NFBPartitionRead((UINT32 *) (eboot_des->dwLoadPhyAddr), u4LogEbootBlockStart*u4BlockSize,eboot_des->dwTtlLen, (UINT8*)MEM_BUF_MTD_TMP_MEM_PTR) == FALSE)
	        {
		        Printf("\t Read Backup Eboot Info Failed\n");
	        }
		}
	}
	else
	{
	    Printf("\t Eboot Address is 0x%08x\n", eboot_des->dwStartAddr);
	    if(i4NFBPartitionRead((UINT32 *) (eboot_des->dwLoadPhyAddr), eboot_des->dwStartAddr,eboot_des->dwTtlLen, (UINT8*)MEM_BUF_MTD_TMP_MEM_PTR)!= TRUE)
		{
		    bRet = i4NFBPartitionRead((UINT32 *) (eboot_des->dwLoadPhyAddr), (eboot_des->dwStartAddr+_rBLHeader.pagesPerBlock*_rBLHeader.NFIinfo.pageSize),
				eboot_des->dwTtlLen, (UINT8*)MEM_BUF_MTD_TMP_MEM_PTR);
			Printf("\t Read Before Relocate Eboot Info Failed\n");
		}
	}
	return bRet;
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:          JumpToEboot

Description:      Jump to Eboot

Arguments:      
		
Return Value:    

-------------------------------------------------------------------*/
void JumpToEboot()
{
   
    IMAGE_DESCRIPTOR *eboot_des;
	UINT32 u4RelBL = 0;
	
    /*1. Get Jump Information from Datazone*/
	GetDataZoneInfo((UINT32 *)MEM_BUF_SECURE_BOOT_1);

	eboot_des = ((IMAGE_DESCRIPTOR*)(MEM_BUF_SECURE_BOOT_1));
	u4RelBL 	   =*(UINT32 *)(MEM_BUF_SECURE_BOOT_1+ RELBL_START);
	Printf("eboot_img_des(final data):\n");
	Printf("\tdwLoadAddress:0x%08x\n", eboot_des->dwLoadAddress);
	Printf("\tdwLoadPhyAddr:0x%08x\n", eboot_des->dwLoadPhyAddr);
	Printf("\tdwJumpAddress:0x%08x\n", eboot_des->dwJumpAddress);
	Printf("\tdwJumpPhyAddr:0x%08x\n", eboot_des->dwJumpPhyAddr);
	Printf("\tdwStartAddr:0x%08x\n", eboot_des->dwStartAddr);
	Printf("\tdwdwTtlLen:0x%08x\n", eboot_des->dwTtlLen);
	Printf("\t4RelBl:0x%08x\n", u4RelBL);

	/*2. Get Eboot Content to memory*/
	if(GetEbootContent(eboot_des,u4RelBL) == TRUE)
	{
	    /*3. Jump to Eboot*/
	    ((FUNC_CALL)(eboot_des->dwJumpPhyAddr))();
	}

}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Function:          MoveSectionByNand

Description:      Move Section By NandFlash

Arguments:      u4SecStart  - [in] Section  Start 
                        u4SecLen    - [in] Section Length
                        pu4MovBuf   -[in/out] move buffer
                        pu4TmpBuf  -[in ]Tmp buffer
                        
		
Return Value:    TRUE on success

-------------------------------------------------------------------*/
BOOL MoveSectionByNand(UINT32 u4SecStart,UINT32 u4SecLen, UINT32 *pu4MovBuf,UINT32 *pu4TmpBuf)
{
    BOOL bRet = TRUE;
    /*1. Get Jump Information from Datazone*/
	if((bRet = i4NFBPartitionRead(pu4MovBuf, u4SecStart, u4SecLen,(UINT8 *)pu4TmpBuf)) == FALSE)
	{
	    Printf("Using  DataZone Address 0x %x:\n",(u4SecStart+_rBLHeader.pagesPerBlock*_rBLHeader.NFIinfo.pageSize));
	    /*2. Get Backup Datazone Address*/ 
		bRet = i4NFBPartitionRead(pu4MovBuf, (u4SecStart+_rBLHeader.pagesPerBlock*_rBLHeader.NFIinfo.pageSize),
		      u4SecLen,(UINT8 *)pu4TmpBuf);
	}
	return bRet;
}




void RunInNand()
{
    UINT8 *pDramkStart = (UINT8 *)(&_dramk_loader_start);
    UINT8 *pDramkEnd   = (UINT8 *)(&_dramk_loader_end);
	  UINT32 u4DramkLength = pDramkEnd - pDramkStart; 
	
    /*1. NandFlash Initialize */
	  NandFlashInfoInit((UINT32 *)DRAMK_SDRAM_ADDR);
    u4DramkLength = ALIGN((pDramkEnd - pDramkStart), _rBLHeader.NFIinfo.pageSize); 

    Printf("DDRK pDramkStart 0x%x pDramkEnd 0x%x u4DramkLength 0x%x: Page Size 0x%x\n",
        pDramkStart,pDramkEnd,u4DramkLength,_rBLHeader.NFIinfo.pageSize);
	
	  /*2. Move Section By Nand*/
	  MoveSectionByNand((UINT32)(pDramkStart + PLR_HEAD_SIZE - SDRAM_ADDR_START) ,u4DramkLength, (UINT32 *)DRAMK_SDRAM_ADDR, (UINT32 *)TMP_SDRAM_ADDR);

	  /*3. DDR Initialiaze*/
	  DDR_Initialize();

	  ddr_calibrate();
	  /*4. Jump to Eboot*/
	  JumpToEboot();
}


